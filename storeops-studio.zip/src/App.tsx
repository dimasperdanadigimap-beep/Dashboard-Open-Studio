import { useState } from 'react';
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck,
  Clock,
  ExternalLink,
  FileText,
  LayoutDashboard,
  Lock,
  Menu,
  PlusSquare,
  Unlock,
  X,
} from 'lucide-react';
import { AdminAndCashierView, AdminSubTab } from './components/AdminAndCashierView';
import { DashboardOverview } from './components/DashboardOverview';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ScheduleAndAuditView } from './components/ScheduleAndAuditView';
import { StaffActivityForm } from './components/StaffActivityForm';
import { useStoreData } from './hooks/useStoreData';
import {
  downloadWeeklyTemplateExcel,
  generateSampleWeeklySchedule,
} from './lib/excelParser';
import {
  formatWeekLabel,
  getIsoWeekKeyFromDate,
  getMondayDateFromWeekKey,
  getTodayDateStr,
  shiftWeekKey,
  toDateStr,
} from './lib/formatters';
import { AppTab, ViewRole } from './types/operations';

const ADMIN_SESSION_KEY = 'storeops_admin_unlocked';
const ADMIN_PASSCODE = 'Admin00';

function StoreOpsWorkspace() {
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateStr());
  const weekKey = getIsoWeekKeyFromDate(selectedDate);

  const [activeTab, setActiveTab] = useState<AppTab>('dashboard');
  const [adminSubTab, setAdminSubTab] = useState<AdminSubTab>('cashier');
  const [viewRole, setViewRole] = useState<ViewRole>('staff');
  const [preselectStaffId, setPreselectStaffId] = useState<string | undefined>(undefined);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const [adminUnlocked, setAdminUnlocked] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(ADMIN_SESSION_KEY) === 'true';
    } catch {
      return false;
    }
  });
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [modalPassword, setModalPassword] = useState('');
  const [modalError, setModalError] = useState<string | null>(null);
  const [pendingRoleAfterUnlock, setPendingRoleAfterUnlock] = useState<boolean>(false);

  const data = useStoreData(weekKey);

  const handleUnlockAdmin = (password: string): boolean => {
    if (password === ADMIN_PASSCODE) {
      setAdminUnlocked(true);
      try {
        sessionStorage.setItem(ADMIN_SESSION_KEY, 'true');
      } catch {
        // ignore storage errors
      }
      return true;
    }
    return false;
  };

  const handleLockAdmin = () => {
    setAdminUnlocked(false);
    try {
      sessionStorage.removeItem(ADMIN_SESSION_KEY);
    } catch {
      // ignore storage errors
    }
    if (viewRole === 'admin') {
      setViewRole('staff');
    }
    if (activeTab === 'admin_cashier' && adminSubTab !== 'cashier') {
      setAdminSubTab('cashier');
    }
  };

  const handleRoleSwitch = (role: ViewRole) => {
    if (role === 'admin' && !adminUnlocked) {
      setPendingRoleAfterUnlock(true);
      setModalPassword('');
      setModalError(null);
      setShowAdminModal(true);
      return;
    }
    setViewRole(role);
    if (role === 'staff') {
      setActiveTab('input');
    } else if (role === 'kasir') {
      setActiveTab('admin_cashier');
      setAdminSubTab('cashier');
    } else {
      setActiveTab('admin_cashier');
      setAdminSubTab('schedule_target');
    }
    setMobileDrawerOpen(false);
  };

  const handleAdminModalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError(null);
    if (handleUnlockAdmin(modalPassword)) {
      setShowAdminModal(false);
      setModalPassword('');
      if (pendingRoleAfterUnlock) {
        setViewRole('admin');
        setActiveTab('admin_cashier');
        setAdminSubTab('schedule_target');
        setPendingRoleAfterUnlock(false);
      }
    } else {
      setModalError('Password Admin salah.');
    }
  };

  const handleNavigateTab = (tab: AppTab, staffId?: string) => {
    setPreselectStaffId(staffId);
    setActiveTab(tab);
    setMobileDrawerOpen(false);
    if (tab === 'admin_cashier') {
      setAdminSubTab(adminUnlocked ? 'schedule_target' : 'cashier');
    }
  };

  const handleLoadSampleSchedule = async () => {
    if (!adminUnlocked) {
      setPendingRoleAfterUnlock(false);
      setModalPassword('');
      setModalError(null);
      setShowAdminModal(true);
      return;
    }
    const sample = generateSampleWeeklySchedule(weekKey);
    await data.uploadParsedSchedule(sample, `Jadwal_Mingguan_${weekKey}.xlsx`);
  };

  const handleShiftWeek = (delta: number) => {
    const nextWeekKey = shiftWeekKey(weekKey, delta);
    const nextMonday = getMondayDateFromWeekKey(nextWeekKey);
    setSelectedDate(toDateStr(nextMonday));
  };

  const navItems: Array<{
    id: AppTab;
    label: string;
    shortLabel: string;
    icon: typeof LayoutDashboard;
  }> = [
    { id: 'dashboard', label: 'Dashboard', shortLabel: 'Dashboard', icon: LayoutDashboard },
    { id: 'input', label: 'Input Aktivitas', shortLabel: 'Input', icon: PlusSquare },
    { id: 'schedule', label: 'Jadwal Mingguan', shortLabel: 'Jadwal', icon: CalendarDays },
    { id: 'admin_cashier', label: 'Admin & Kasir', shortLabel: 'Admin/Kasir', icon: ClipboardCheck },
  ];

  const surveyTryOnLinks = [
    { label: 'AirPods', url: data.storeSettings.surveyLinks.airpods },
    { label: 'iPad', url: data.storeSettings.surveyLinks.ipad },
    { label: 'Apple Watch', url: data.storeSettings.surveyLinks.watch },
  ];

  const renderSidebarContent = () => (
    <>
      <div className="flex-1 overflow-y-auto px-3 py-5 space-y-6">
        {/* Primary Navigation */}
        <nav aria-label="Menu Utama" className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigateTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Submit Link Report & Survey Try-on */}
        <div className="pt-4 border-t border-slate-100 px-1 space-y-3">
          <div>
            <p className="px-2 text-xs font-semibold text-slate-800 mb-1.5">
              Submit Link Report
            </p>
            {data.storeSettings.surveyLinks.openStudio ? (
              <a
                href={data.storeSettings.surveyLinks.openStudio}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between px-2.5 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
              >
                <span className="inline-flex items-center gap-2 truncate">
                  <FileText className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                  Open Studio
                </span>
                <ExternalLink className="w-3 h-3 text-slate-400 shrink-0" />
              </a>
            ) : (
              <span className="flex items-center justify-between px-2.5 py-2 text-xs text-slate-400">
                <span>Open Studio</span>
                <span>Segera hadir</span>
              </span>
            )}
          </div>

          <div>
            <p className="px-2 text-xs font-medium text-slate-500 mb-1">
              Survey Try-on
            </p>
            <div className="space-y-0.5">
              {surveyTryOnLinks.map((item) =>
                item.url ? (
                  <a
                    key={item.label}
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between px-2.5 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
                  >
                    <span className="inline-flex items-center gap-2 truncate">
                      <FileText className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      {item.label}
                    </span>
                    <ExternalLink className="w-3 h-3 text-slate-400 shrink-0" />
                  </a>
                ) : (
                  <div
                    key={item.label}
                    aria-disabled="true"
                    className="flex items-center justify-between px-2.5 py-2 text-xs text-slate-400 cursor-not-allowed"
                  >
                    <span className="inline-flex items-center gap-2 truncate">
                      <Clock className="w-3.5 h-3.5 text-slate-300 shrink-0" />
                      {item.label}
                    </span>
                    <span className="text-[11px] italic">Segera hadir</span>
                  </div>
                ),
              )}
            </div>
          </div>
        </div>

        {/* Role Switcher */}
        <div className="pt-4 border-t border-slate-100 px-1">
          <p className="px-2 text-xs font-medium text-slate-500 mb-2">
            Mode Akses
          </p>
          <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg">
            {(['staff', 'kasir', 'admin'] as ViewRole[]).map((role) => (
              <button
                key={role}
                type="button"
                onClick={() => handleRoleSwitch(role)}
                className={`py-1.5 px-1.5 text-xs font-medium rounded-md capitalize inline-flex items-center justify-center gap-1 transition-colors ${
                  viewRole === role
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {role === 'admin' && !adminUnlocked && <Lock className="w-3 h-3" />}
                {role}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Sidebar Footer: Admin Lock/Unlock */}
      <div className="p-4 border-t border-slate-200">
        {adminUnlocked ? (
          <button
            type="button"
            onClick={handleLockAdmin}
            className="w-full flex items-center justify-between px-3 py-2 text-xs font-medium text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors"
          >
            <span className="inline-flex items-center gap-1.5">
              <Unlock className="w-3.5 h-3.5" />
              Admin Terbuka
            </span>
            <span>Kunci</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => {
              setPendingRoleAfterUnlock(false);
              setModalPassword('');
              setModalError(null);
              setShowAdminModal(true);
            }}
            className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <Lock className="w-3.5 h-3.5" />
            Masuk Mode Admin
          </button>
        )}
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col lg:flex-row">
      {/* Desktop Left Sidebar Navigation (256px) */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-white border-r border-slate-200 z-30">
        <div className="px-5 h-16 flex items-center border-b border-slate-200">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className="font-display text-lg font-bold tracking-tight text-slate-900 text-left"
          >
            StoreOps Studio
          </button>
        </div>
        {renderSidebarContent()}
      </aside>

      {/* Mobile Slide-Over Sidebar Drawer */}
      {mobileDrawerOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-slate-900/50 flex"
          onClick={() => setMobileDrawerOpen(false)}
        >
          <aside
            className="w-72 max-w-[85vw] bg-white h-full flex flex-col border-r border-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 h-14 flex items-center justify-between border-b border-slate-200">
              <span className="font-display text-base font-bold text-slate-900">
                StoreOps Studio
              </span>
              <button
                type="button"
                aria-label="Tutup menu"
                onClick={() => setMobileDrawerOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {renderSidebarContent()}
          </aside>
        </div>
      )}

      {/* Mobile Header */}
      <header className="lg:hidden bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="px-4 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              aria-label="Buka menu sidebar"
              onClick={() => setMobileDrawerOpen(true)}
              className="p-2 -ml-2 text-slate-700 hover:bg-slate-100 rounded-lg"
            >
              <Menu className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('dashboard')}
              className="font-display text-base font-bold tracking-tight text-slate-900 whitespace-nowrap"
            >
              StoreOps Studio
            </button>
          </div>

          <div className="flex items-center gap-2">
            {adminUnlocked ? (
              <button
                type="button"
                onClick={handleLockAdmin}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-amber-800 bg-amber-50 border border-amber-200 rounded-lg"
              >
                <Unlock className="w-3.5 h-3.5" />
                Admin
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setPendingRoleAfterUnlock(true);
                  setModalPassword('');
                  setModalError(null);
                  setShowAdminModal(true);
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
              >
                <Lock className="w-3.5 h-3.5" />
                Admin
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <main className="max-w-6xl w-full mx-auto px-4 sm:px-6 pt-5 pb-24 lg:pb-10 space-y-6">
          {/* Context Header & Weekly Senin-Minggu Selector */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span className="font-medium text-slate-700">
                  {data.storeSettings.storeName}
                </span>
                <span aria-hidden="true">·</span>
                <span>{formatWeekLabel(weekKey)}</span>
                <span aria-hidden="true">·</span>
                <span>
                  {adminUnlocked ? 'Mode Admin Terbuka' : 'Akses Publik Online'}
                </span>
              </div>
              <h1 className="mt-1 text-xl font-semibold text-slate-900">
                {activeTab === 'dashboard' && 'Dashboard Ringkasan Operasional'}
                {activeTab === 'input' && 'Input Aktivitas Open Studio & Try-on'}
                {activeTab === 'schedule' && 'Jadwal Mingguan (Senin–Minggu) & Audit'}
                {activeTab === 'admin_cashier' && 'Laporan Kasir & Panel Admin'}
              </h1>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex items-center border border-slate-300 rounded-lg bg-white overflow-hidden">
                <button
                  type="button"
                  onClick={() => handleShiftWeek(-1)}
                  aria-label="Minggu sebelumnya"
                  className="p-2 text-slate-600 hover:bg-slate-100 border-r border-slate-200"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="px-3 py-1.5 text-xs font-mono text-slate-800 whitespace-nowrap">
                  {weekKey}
                </span>
                <button
                  type="button"
                  onClick={() => handleShiftWeek(1)}
                  aria-label="Minggu berikutnya"
                  className="p-2 text-slate-600 hover:bg-slate-100 border-l border-slate-200"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <input
                type="date"
                aria-label="Pilih Tanggal"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="min-h-[38px] px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
              />

              <button
                type="button"
                onClick={() => setSelectedDate(getTodayDateStr())}
                className="min-h-[38px] px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg whitespace-nowrap"
              >
                Hari Ini
              </button>
            </div>
          </div>

          {!data.connectionOk && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
              Koneksi Firestore terdeteksi offline. Perubahan akan disinkronkan saat jaringan kembali.
            </div>
          )}

          {activeTab === 'dashboard' && (
            <DashboardOverview
              weekKey={weekKey}
              selectedDate={selectedDate}
              loadingData={data.loadingData}
              storeSettings={data.storeSettings}
              scheduleMeta={data.scheduleMeta}
              staffRoster={data.staffRoster}
              targetConfig={data.targetConfig}
              activities={data.activities}
              cashierReports={data.cashierReports}
              onNavigateTab={handleNavigateTab}
              onLoadSampleSchedule={handleLoadSampleSchedule}
              onSelectDate={setSelectedDate}
            />
          )}

          {activeTab === 'input' && (
            <StaffActivityForm
              selectedDate={selectedDate}
              onChangeDate={setSelectedDate}
              preselectedStaffId={preselectStaffId}
              staffRoster={data.staffRoster}
              activities={data.activities}
              storeSettings={data.storeSettings}
              onCreateActivity={data.createActivity}
              onUpdateActivity={data.updateActivityContent}
              onDeleteActivity={data.deleteActivity}
              onGoToDriveConfig={() => {
                setActiveTab('admin_cashier');
                setAdminSubTab('integration');
              }}
            />
          )}

          {activeTab === 'schedule' && (
            <ScheduleAndAuditView
              weekKey={weekKey}
              selectedDate={selectedDate}
              staffRoster={data.staffRoster}
              activities={data.activities}
              targetConfig={data.targetConfig}
              onDownloadTemplate={() => downloadWeeklyTemplateExcel(weekKey)}
            />
          )}

          {activeTab === 'admin_cashier' && (
            <AdminAndCashierView
              activeSubTab={adminSubTab}
              onChangeSubTab={setAdminSubTab}
              adminUnlocked={adminUnlocked}
              onUnlockAdmin={handleUnlockAdmin}
              onLockAdmin={handleLockAdmin}
              weekKey={weekKey}
              selectedDate={selectedDate}
              storeSettings={data.storeSettings}
              staffRoster={data.staffRoster}
              targetConfig={data.targetConfig}
              activities={data.activities}
              cashierReports={data.cashierReports}
              onSaveStoreSettings={data.saveStoreSettings}
              onUploadParsedSchedule={data.uploadParsedSchedule}
              onLoadSampleSchedule={handleLoadSampleSchedule}
              onSaveTargetConfig={data.saveTargetConfig}
              onCreateCashierReport={data.createCashierReport}
              onDeleteCashierReport={data.deleteCashierReport}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <nav
        aria-label="Navigasi Mobile"
        className="lg:hidden fixed bottom-0 inset-x-0 bg-white border-t border-slate-200 z-30 grid grid-cols-4"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavigateTab(item.id)}
              className={`min-h-[54px] flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${
                isActive ? 'text-slate-900 bg-slate-50' : 'text-slate-500'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="truncate max-w-full px-1">{item.shortLabel}</span>
            </button>
          );
        })}
      </nav>

      {/* Admin Password Modal */}
      {showAdminModal && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4"
          onClick={() => setShowAdminModal(false)}
        >
          <div
            className="bg-white border border-slate-200 rounded-xl max-w-sm w-full p-5 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-slate-700" />
                <h3 className="text-base font-semibold text-slate-900">
                  Verifikasi Password Admin
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAdminModal(false)}
                className="p-1 text-slate-500 hover:text-slate-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-slate-600">
              Bagian Admin dilindungi password. Staff dan Kasir tetap dapat menggunakan halaman lain tanpa login.
            </p>
            <form onSubmit={handleAdminModalSubmit} className="space-y-3">
              <input
                type="password"
                required
                autoFocus
                value={modalPassword}
                onChange={(e) => setModalPassword(e.target.value)}
                placeholder="Masukkan password Admin"
                className="w-full min-h-[42px] px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
              {modalError && (
                <p className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-md px-2.5 py-1.5">
                  {modalError}
                </p>
              )}
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAdminModal(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                >
                  Buka Admin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <StoreOpsWorkspace />
    </ErrorBoundary>
  );
}
