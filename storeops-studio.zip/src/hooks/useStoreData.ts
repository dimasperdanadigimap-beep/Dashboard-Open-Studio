import { useEffect, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  DEFAULT_DAILY_QUOTAS,
  DEFAULT_MANUAL_TOTALS,
} from '../lib/analytics';
import { DEFAULT_DRIVE_FOLDERS } from '../lib/driveUploader';
import { ParsedWeeklyScheduleResult } from '../lib/excelParser';
import {
  db,
  handleFirestoreError,
  OperationType,
  testConnection,
} from '../lib/firebase';
import {
  CashierReport,
  CashierTryOnCounts,
  StaffActivity,
  StoreSettings,
  SurveyLinkMap,
  WeeklySchedule,
  WeeklyStaffShift,
  WeeklyTargetConfig,
} from '../types/operations';

export const DEFAULT_SURVEY_LINKS: SurveyLinkMap = {
  openStudio: 'https://forms.gle/mfseNo9aRQmVnSBd8',
  airpods:
    'https://docs.google.com/forms/d/e/1FAIpQLSdDj3fPWA5_tZ7xBcjEhb8hMn0DAQ5Ok_joASUjwStYUjC5Ow/viewform',
  ipad: 'https://forms.gle/BZphsLuhdCtF71J1A',
  watch: '',
};

export interface StoreDataHook {
  connectionOk: boolean;
  loadingData: boolean;
  storeSettings: StoreSettings;
  scheduleMeta: WeeklySchedule | null;
  staffRoster: WeeklyStaffShift[];
  targetConfig: WeeklyTargetConfig | null;
  activities: StaffActivity[];
  cashierReports: CashierReport[];
  saveStoreSettings: (
    next: Pick<StoreSettings, 'storeName' | 'driveScriptUrl' | 'driveFolders' | 'surveyLinks'>,
  ) => Promise<void>;
  uploadParsedSchedule: (
    parsed: ParsedWeeklyScheduleResult,
    fileName: string,
  ) => Promise<void>;
  saveTargetConfig: (
    next: Omit<WeeklyTargetConfig, 'storeId' | 'updatedAt'>,
  ) => Promise<void>;
  createActivity: (
    payload: Omit<
      StaffActivity,
      'id' | 'storeId' | 'verificationStatus' | 'adminNotes' | 'createdAt' | 'updatedAt'
    >,
  ) => Promise<void>;
  updateActivityContent: (
    activity: StaffActivity,
    patch: Pick<
      StaffActivity,
      'topic' | 'participantsCount' | 'productCategory' | 'customerNotes' | 'photoUrl' | 'photoSource'
    >,
  ) => Promise<void>;
  deleteActivity: (activityId: string) => Promise<void>;
  createCashierReport: (
    payload: Omit<CashierReport, 'id' | 'storeId' | 'createdAt' | 'updatedAt'>,
  ) => Promise<void>;
  deleteCashierReport: (reportId: string) => Promise<void>;
}

const DEFAULT_SETTINGS: StoreSettings = {
  storeId: 'store-main',
  storeName: import.meta.env.VITE_STORE_NAME || 'Flagship Retail Store',
  driveScriptUrl: import.meta.env.VITE_GOOGLE_DRIVE_SCRIPT_URL || '',
  driveFolders: DEFAULT_DRIVE_FOLDERS,
  surveyLinks: DEFAULT_SURVEY_LINKS,
};

export function useStoreData(weekKey: string): StoreDataHook {
  const [connectionOk, setConnectionOk] = useState(true);
  const [loadingData, setLoadingData] = useState(true);

  const [storeSettings, setStoreSettings] = useState<StoreSettings>(DEFAULT_SETTINGS);
  const [scheduleMeta, setScheduleMeta] = useState<WeeklySchedule | null>(null);
  const [staffRoster, setStaffRoster] = useState<WeeklyStaffShift[]>([]);
  const [targetConfig, setTargetConfig] = useState<WeeklyTargetConfig | null>(null);
  const [activities, setActivities] = useState<StaffActivity[]>([]);
  const [cashierReports, setCashierReports] = useState<CashierReport[]>([]);

  useEffect(() => {
    testConnection().then(setConnectionOk);
  }, []);

  useEffect(() => {
    setLoadingData(true);

    const settingsRef = doc(db, 'storeSettings', 'main');
    const unsubSettings = onSnapshot(
      settingsRef,
      (snap) => {
        if (snap.exists()) {
          const d = snap.data() as Partial<StoreSettings>;
          setStoreSettings({
            ...DEFAULT_SETTINGS,
            ...d,
            driveFolders: {
              ...DEFAULT_DRIVE_FOLDERS,
              ...(d.driveFolders || {}),
            },
            surveyLinks: {
              ...DEFAULT_SURVEY_LINKS,
              ...(d.surveyLinks || {}),
            },
          });
        } else {
          setStoreSettings(DEFAULT_SETTINGS);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, 'storeSettings/main'),
    );

    const scheduleRef = doc(db, 'weeklySchedules', weekKey);
    const unsubSchedule = onSnapshot(
      scheduleRef,
      (snap) => {
        setScheduleMeta(snap.exists() ? (snap.data() as WeeklySchedule) : null);
      },
      (err) => handleFirestoreError(err, OperationType.GET, `weeklySchedules/${weekKey}`),
    );

    const staffQuery = query(
      collection(db, 'weeklySchedules', weekKey, 'staff'),
      where('storeId', '==', 'store-main'),
    );
    const unsubStaff = onSnapshot(
      staffQuery,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as WeeklyStaffShift);
        list.sort((a, b) => a.name.localeCompare(b.name));
        setStaffRoster(list);
      },
      (err) =>
        handleFirestoreError(err, OperationType.LIST, `weeklySchedules/${weekKey}/staff`),
    );

    const targetRef = doc(db, 'weeklyTargets', weekKey);
    const unsubTargets = onSnapshot(
      targetRef,
      (snap) => {
        setTargetConfig(snap.exists() ? (snap.data() as WeeklyTargetConfig) : null);
      },
      (err) => handleFirestoreError(err, OperationType.GET, `weeklyTargets/${weekKey}`),
    );

    const activitiesQuery = query(
      collection(db, 'activities'),
      where('storeId', '==', 'store-main'),
    );
    const unsubActivities = onSnapshot(
      activitiesQuery,
      (snap) => {
        const list = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<StaffActivity, 'id'>),
        }));
        list.sort((a, b) => b.date.localeCompare(a.date));
        setActivities(list);
        setLoadingData(false);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'activities'),
    );

    const cashierQuery = query(
      collection(db, 'cashierReports'),
      where('storeId', '==', 'store-main'),
    );
    const unsubCashier = onSnapshot(
      cashierQuery,
      (snap) => {
        const list = snap.docs.map((d) => {
          const raw = d.data() as Record<string, unknown>;
          const rawTryOn = (raw.tryOnCounts as Partial<CashierTryOnCounts> | undefined) ?? {};
          const tryOnCounts: CashierTryOnCounts = {
            airpods: Number(rawTryOn.airpods) || 0,
            ipad: Number(rawTryOn.ipad) || 0,
            watch: Number(rawTryOn.watch) || 0,
          };
          const totalTryOnCount =
            typeof raw.totalTryOnCount === 'number'
              ? raw.totalTryOnCount
              : tryOnCounts.airpods + tryOnCounts.ipad + tryOnCounts.watch;
          return {
            id: d.id,
            storeId: 'store-main' as const,
            date: String(raw.date ?? ''),
            weekKey: String(raw.weekKey ?? ''),
            monthKey: String(raw.monthKey ?? ''),
            shift: (raw.shift as CashierReport['shift']) || 'Full Day',
            cashierName: String(raw.cashierName ?? 'Kasir'),
            openStudioCount: Number(raw.openStudioCount) || 0,
            openStudioParticipants: Number(raw.openStudioParticipants) || 0,
            tryOnCounts,
            totalTryOnCount,
            handoverNotes: String(raw.handoverNotes ?? ''),
            createdAt: raw.createdAt,
            updatedAt: raw.updatedAt,
          };
        });
        list.sort((a, b) => b.date.localeCompare(a.date));
        setCashierReports(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'cashierReports'),
    );

    return () => {
      unsubSettings();
      unsubSchedule();
      unsubStaff();
      unsubTargets();
      unsubActivities();
      unsubCashier();
    };
  }, [weekKey]);

  const saveStoreSettings = async (
    next: Pick<StoreSettings, 'storeName' | 'driveScriptUrl' | 'driveFolders' | 'surveyLinks'>,
  ) => {
    const ref = doc(db, 'storeSettings', 'main');
    try {
      const snap = await getDoc(ref);
      const payload = {
        storeName: next.storeName.trim().slice(0, 120) || 'Flagship Retail Store',
        driveScriptUrl: next.driveScriptUrl.trim().slice(0, 500),
        driveFolders: {
          openStudio: next.driveFolders.openStudio.trim().slice(0, 500),
          airpods: next.driveFolders.airpods.trim().slice(0, 500),
          ipad: next.driveFolders.ipad.trim().slice(0, 500),
          watch: next.driveFolders.watch.trim().slice(0, 500),
        },
        surveyLinks: {
          openStudio: next.surveyLinks.openStudio.trim().slice(0, 500),
          airpods: next.surveyLinks.airpods.trim().slice(0, 500),
          ipad: next.surveyLinks.ipad.trim().slice(0, 500),
          watch: next.surveyLinks.watch.trim().slice(0, 500),
        },
        updatedAt: serverTimestamp(),
      };
      if (snap.exists()) {
        await updateDoc(ref, payload);
      } else {
        await setDoc(ref, {
          storeId: 'store-main',
          ...payload,
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'storeSettings/main');
    }
  };

  const uploadParsedSchedule = async (
    parsed: ParsedWeeklyScheduleResult,
    fileName: string,
  ) => {
    const scheduleRef = doc(db, 'weeklySchedules', parsed.weekKey);
    try {
      const existingSnap = await getDoc(scheduleRef);
      if (existingSnap.exists()) {
        await updateDoc(scheduleRef, {
          weekLabel: parsed.weekLabel.slice(0, 80),
          startDate: parsed.startDate,
          endDate: parsed.endDate,
          fileName: fileName.slice(0, 160),
          totalStaff: parsed.records.length,
          totalActiveShifts: parsed.totalActiveShifts,
          updatedAt: serverTimestamp(),
        });
      } else {
        await setDoc(scheduleRef, {
          storeId: 'store-main',
          weekKey: parsed.weekKey,
          weekLabel: parsed.weekLabel.slice(0, 80),
          startDate: parsed.startDate,
          endDate: parsed.endDate,
          fileName: fileName.slice(0, 160),
          totalStaff: parsed.records.length,
          totalActiveShifts: parsed.totalActiveShifts,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      const newStaffIds = new Set(parsed.records.map((r) => r.staffId));
      const batch = writeBatch(db);
      for (const oldRec of staffRoster) {
        if (oldRec.weekKey === parsed.weekKey && !newStaffIds.has(oldRec.staffId)) {
          batch.delete(
            doc(db, 'weeklySchedules', parsed.weekKey, 'staff', oldRec.staffId),
          );
        }
      }
      for (const rec of parsed.records) {
        const staffDocRef = doc(
          db,
          'weeklySchedules',
          parsed.weekKey,
          'staff',
          rec.staffId,
        );
        batch.set(staffDocRef, {
          ...rec,
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();

      const targetRef = doc(db, 'weeklyTargets', parsed.weekKey);
      const targetSnap = await getDoc(targetRef);
      if (!targetSnap.exists()) {
        await setDoc(targetRef, {
          storeId: 'store-main',
          weekKey: parsed.weekKey,
          mode: 'auto',
          dailyQuotas: DEFAULT_DAILY_QUOTAS,
          manualTotals: DEFAULT_MANUAL_TOTALS,
          staffOverrides: {},
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `weeklySchedules/${parsed.weekKey}`);
    }
  };

  const saveTargetConfig = async (
    next: Omit<WeeklyTargetConfig, 'storeId' | 'updatedAt'>,
  ) => {
    const ref = doc(db, 'weeklyTargets', next.weekKey);
    try {
      const snap = await getDoc(ref);
      if (snap.exists()) {
        await updateDoc(ref, {
          mode: next.mode,
          dailyQuotas: next.dailyQuotas,
          manualTotals: next.manualTotals,
          staffOverrides: next.staffOverrides,
          updatedAt: serverTimestamp(),
        });
      } else {
        await setDoc(ref, {
          storeId: 'store-main',
          weekKey: next.weekKey,
          mode: next.mode,
          dailyQuotas: next.dailyQuotas,
          manualTotals: next.manualTotals,
          staffOverrides: next.staffOverrides,
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `weeklyTargets/${next.weekKey}`);
    }
  };

  const createActivity: StoreDataHook['createActivity'] = async (payload) => {
    const id = `act-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const ref = doc(db, 'activities', id);
    try {
      await setDoc(ref, {
        storeId: 'store-main',
        date: payload.date,
        weekKey: payload.weekKey,
        monthKey: payload.monthKey,
        staffId: payload.staffId,
        staffName: payload.staffName.slice(0, 120),
        staffRole: payload.staffRole.slice(0, 80),
        shiftCode: payload.shiftCode,
        activityType: payload.activityType,
        topic: payload.topic.slice(0, 200),
        participantsCount: Math.max(0, Math.min(500, Math.round(payload.participantsCount))),
        productCategory: payload.productCategory,
        customerNotes: payload.customerNotes.slice(0, 500),
        photoUrl: payload.photoUrl.slice(0, 1000),
        photoSource: payload.photoSource,
        verificationStatus: 'pending',
        adminNotes: '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `activities/${id}`);
    }
  };

  const updateActivityContent: StoreDataHook['updateActivityContent'] = async (
    activity,
    patch,
  ) => {
    const ref = doc(db, 'activities', activity.id);
    try {
      await updateDoc(ref, {
        topic: patch.topic.slice(0, 200),
        participantsCount: Math.max(0, Math.min(500, Math.round(patch.participantsCount))),
        productCategory: patch.productCategory,
        customerNotes: patch.customerNotes.slice(0, 500),
        photoUrl: patch.photoUrl.slice(0, 1000),
        photoSource: patch.photoSource,
        verificationStatus: 'pending',
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `activities/${activity.id}`);
    }
  };

  const deleteActivity = async (activityId: string) => {
    try {
      await deleteDoc(doc(db, 'activities', activityId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `activities/${activityId}`);
    }
  };

  const createCashierReport: StoreDataHook['createCashierReport'] = async (payload) => {
    const id = `rep-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const ref = doc(db, 'cashierReports', id);
    const airpods = Math.max(0, Math.round(payload.tryOnCounts.airpods));
    const ipad = Math.max(0, Math.round(payload.tryOnCounts.ipad));
    const watch = Math.max(0, Math.round(payload.tryOnCounts.watch));
    try {
      await setDoc(ref, {
        storeId: 'store-main',
        date: payload.date,
        weekKey: payload.weekKey,
        monthKey: payload.monthKey,
        shift: payload.shift,
        cashierName: payload.cashierName.slice(0, 120),
        openStudioCount: Math.max(0, Math.round(payload.openStudioCount)),
        openStudioParticipants: Math.max(0, Math.round(payload.openStudioParticipants)),
        tryOnCounts: { airpods, ipad, watch },
        totalTryOnCount: airpods + ipad + watch,
        handoverNotes: payload.handoverNotes.slice(0, 800),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `cashierReports/${id}`);
    }
  };

  const deleteCashierReport = async (reportId: string) => {
    try {
      await deleteDoc(doc(db, 'cashierReports', reportId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `cashierReports/${reportId}`);
    }
  };

  return {
    connectionOk,
    loadingData,
    storeSettings,
    scheduleMeta,
    staffRoster,
    targetConfig,
    activities,
    cashierReports,
    saveStoreSettings,
    uploadParsedSchedule,
    saveTargetConfig,
    createActivity,
    updateActivityContent,
    deleteActivity,
    createCashierReport,
    deleteCashierReport,
  };
}
