export type ShiftCode = 'P' | 'M' | 'S' | 'X';
export type ActiveShiftCode = 'P' | 'M' | 'S';
export type WeekDayKey = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';
export type ViewRole = 'staff' | 'kasir' | 'admin';
export type AppTab = 'dashboard' | 'input' | 'schedule' | 'admin_cashier';

export type ActivityType = 'open_studio' | 'try_on';
export type TryOnProductCategory = 'AirPods' | 'iPad' | 'Apple Watch';
export type VerificationStatus = 'pending' | 'verified' | 'revision';
export type PhotoSource =
  | 'gdrive_apps_script'
  | 'manual_link'
  | 'drive_folder_fallback'
  | 'none';
export type TargetMode = 'auto' | 'manual';

export interface ShiftCounts {
  P: number;
  M: number;
  S: number;
  X: number;
}

export interface DriveFolderMap {
  openStudio: string;
  airpods: string;
  ipad: string;
  watch: string;
}

export interface SurveyLinkMap {
  openStudio: string;
  airpods: string;
  ipad: string;
  watch: string;
}

export interface StoreSettings {
  storeId: 'store-main';
  storeName: string;
  driveScriptUrl: string;
  driveFolders: DriveFolderMap;
  surveyLinks: SurveyLinkMap;
  updatedAt?: unknown;
}

export interface WeeklySchedule {
  storeId: 'store-main';
  weekKey: string; // YYYY-Www e.g. 2026-W47
  weekLabel: string;
  startDate: string; // YYYY-MM-DD (Monday)
  endDate: string; // YYYY-MM-DD (Sunday)
  fileName: string;
  totalStaff: number;
  totalActiveShifts: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface WeeklyStaffShift {
  storeId: 'store-main';
  weekKey: string;
  staffId: string;
  name: string;
  role: string;
  shifts: Record<WeekDayKey, ShiftCode>;
  totalActiveDays: number;
  counts: ShiftCounts;
  updatedAt?: unknown;
}

export interface TargetQuotas {
  openStudio: number;
  airpods: number;
  ipad: number;
  watch: number;
}

export interface WeeklyTargetConfig {
  storeId: 'store-main';
  weekKey: string;
  mode: TargetMode;
  dailyQuotas: TargetQuotas;
  manualTotals: TargetQuotas;
  staffOverrides: Record<string, TargetQuotas>;
  updatedAt?: unknown;
}

export interface StaffActivity {
  id: string;
  storeId: 'store-main';
  date: string; // YYYY-MM-DD
  weekKey: string; // YYYY-Www
  monthKey: string; // YYYY-MM
  staffId: string;
  staffName: string;
  staffRole: string;
  shiftCode: ActiveShiftCode;
  activityType: ActivityType;
  topic: string;
  participantsCount: number;
  productCategory: '' | TryOnProductCategory;
  customerNotes: string;
  photoUrl: string;
  photoSource: PhotoSource;
  verificationStatus: VerificationStatus;
  adminNotes: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CashierTryOnCounts {
  airpods: number;
  ipad: number;
  watch: number;
}

export interface CashierReport {
  id: string;
  storeId: 'store-main';
  date: string;
  weekKey: string;
  monthKey: string;
  shift: 'Pagi' | 'Middle' | 'Siang' | 'Full Day';
  cashierName: string;
  openStudioCount: number;
  openStudioParticipants: number;
  tryOnCounts: CashierTryOnCounts;
  totalTryOnCount: number;
  handoverNotes: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}
