import {
  ActivityType,
  DriveFolderMap,
  TryOnProductCategory,
} from '../types/operations';

export const DEFAULT_DRIVE_FOLDERS: DriveFolderMap = {
  openStudio:
    'https://drive.google.com/drive/folders/118nYY6FpDpNZFjTiTjKY0TC81YjU1c3J?hl=ID',
  airpods:
    'https://drive.google.com/drive/folders/19x4y06MnJyC8l3TSSXtiRyh_MyPQuy4i?hl=ID',
  ipad:
    'https://drive.google.com/drive/folders/1Z_Q9bczIFD3GWSuDqvhYHD-B5LyDvx8K?hl=ID',
  watch:
    'https://drive.google.com/drive/folders/1hhhShaUgT6Ku4prSFPMau6ejbsV84KaL?hl=ID',
};

export function extractDriveFolderId(urlOrId: string): string {
  const clean = urlOrId.trim();
  const match = clean.match(/folders\/([a-zA-Z0-9_-]+)/);
  if (match && match[1]) return match[1];
  return clean.replace(/[^a-zA-Z0-9_-]/g, '');
}

export function resolveDriveFolderForActivity(
  folders: DriveFolderMap,
  activityType: ActivityType,
  productCategory: '' | TryOnProductCategory,
): { label: string; url: string; folderId: string } {
  let url = folders.openStudio;
  let label = 'Open Studio';
  if (activityType === 'try_on') {
    if (productCategory === 'AirPods') {
      url = folders.airpods;
      label = 'Try-on AirPods';
    } else if (productCategory === 'iPad') {
      url = folders.ipad;
      label = 'Try-on iPad';
    } else if (productCategory === 'Apple Watch') {
      url = folders.watch;
      label = 'Try-on Apple Watch';
    }
  }
  return {
    label,
    url,
    folderId: extractDriveFolderId(url),
  };
}

export async function compressImageToBase64(file: File): Promise<{
  base64: string;
  mimeType: string;
  previewUrl: string;
}> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Gagal membaca file gambar.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Format gambar tidak didukung.'));
      img.onload = () => {
        const maxDim = 1280;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Gagal memproses canvas gambar.'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        const base64 = dataUrl.split(',')[1] || '';
        resolve({
          base64,
          mimeType: 'image/jpeg',
          previewUrl: dataUrl,
        });
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export async function uploadPhotoToGoogleDrive(
  scriptUrl: string,
  payload: {
    filename: string;
    mimeType: string;
    base64Data: string;
    staffName: string;
    activityType: string;
    productCategory: string;
    folderId: string;
    date: string;
  },
): Promise<{ url: string; fileId?: string }> {
  const cleanUrl = scriptUrl.trim();
  if (!cleanUrl || !cleanUrl.startsWith('https://')) {
    throw new Error('URL Google Apps Script Web App belum dikonfigurasi.');
  }

  const response = await fetch(cleanUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'text/plain;charset=utf-8',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(`Upload ke Google Drive gagal (HTTP ${response.status}).`);
  }

  const json = (await response.json()) as {
    status?: string;
    url?: string;
    fileId?: string;
    error?: string;
  };

  if (json.status === 'error' || !json.url) {
    throw new Error(json.error || 'Respons Google Apps Script tidak valid.');
  }

  return {
    url: json.url,
    fileId: json.fileId,
  };
}

export async function testDriveAppsScriptConnection(scriptUrl: string): Promise<string> {
  const cleanUrl = scriptUrl.trim();
  if (!cleanUrl.startsWith('https://')) {
    throw new Error('Masukkan URL Google Apps Script yang valid (https://script.google.com/macros/s/.../exec).');
  }
  const response = await fetch(cleanUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify({ action: 'ping' }),
  });
  if (!response.ok) {
    throw new Error(`Endpoint merespons HTTP ${response.status}`);
  }
  const json = (await response.json()) as { status?: string; message?: string };
  if (json.status !== 'ok' && json.status !== 'success') {
    throw new Error('Endpoint aktif tetapi format respons tidak sesuai template Code.gs.');
  }
  return json.message || 'Koneksi ke Google Apps Script & Google Drive berhasil.';
}

export const GOOGLE_APPS_SCRIPT_TEMPLATE = `// Salin kode ini ke Google Apps Script (script.google.com)
// Deploy -> New deployment -> Web app -> Execute as: Me -> Who has access: Anyone

const FOLDER_MAP = {
  open_studio: "118nYY6FpDpNZFjTiTjKY0TC81YjU1c3J",
  "AirPods": "19x4y06MnJyC8l3TSSXtiRyh_MyPQuy4i",
  "iPad": "1Z_Q9bczIFD3GWSuDqvhYHD-B5LyDvx8K",
  "Apple Watch": "1hhhShaUgT6Ku4prSFPMau6ejbsV84KaL"
};

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);

    if (body.action === "ping") {
      return ContentService
        .createTextOutput(JSON.stringify({ status: "ok", message: "Bridge Google Drive StoreOps aktif!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    const folderId = body.folderId || FOLDER_MAP[body.productCategory] || FOLDER_MAP[body.activityType] || FOLDER_MAP.open_studio;
    const folder = DriveApp.getFolderById(folderId);
    const bytes = Utilities.base64Decode(body.base64Data);
    const blob = Utilities.newBlob(bytes, body.mimeType || "image/jpeg", body.filename);
    const file = folder.createFile(blob);

    // Agar Admin dapat melihat foto bukti langsung dari Dashboard
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

    const driveUrl = "https://drive.google.com/file/d/" + file.getId() + "/view";
    return ContentService
      .createTextOutput(JSON.stringify({ status: "success", fileId: file.getId(), url: driveUrl }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: "error", error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}`;
