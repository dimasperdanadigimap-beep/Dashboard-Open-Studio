import { CashierReport, ShiftCode, WeekDayKey } from '../types/operations';

export const WEEK_DAYS: Array<{
  key: WeekDayKey;
  label: string;
  shortLabel: string;
  offset: number;
}> = [
  { key: 'mon', label: 'Senin', shortLabel: 'Sen', offset: 0 },
  { key: 'tue', label: 'Selasa', shortLabel: 'Sel', offset: 1 },
  { key: 'wed', label: 'Rabu', shortLabel: 'Rab', offset: 2 },
  { key: 'thu', label: 'Kamis', shortLabel: 'Kam', offset: 3 },
  { key: 'fri', label: 'Jumat', shortLabel: 'Jum', offset: 4 },
  { key: 'sat', label: 'Sabtu', shortLabel: 'Sab', offset: 5 },
  { key: 'sun', label: 'Minggu', shortLabel: 'Min', offset: 6 },
];

export function getTodayDateStr(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseLocalDate(dateStr: string): Date {
  const [y, m, d] = dateStr.split('-').map((n) => Number.parseInt(n, 10));
  return new Date(y || 2026, (m || 1) - 1, d || 1);
}

export function toDateStr(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getMondayOfDate(dateStr: string): Date {
  const dt = parseLocalDate(dateStr);
  const day = dt.getDay(); // 0=Sun, 1=Mon, ...
  const diff = day === 0 ? -6 : 1 - day;
  dt.setDate(dt.getDate() + diff);
  return dt;
}

export function getIsoWeekKeyFromDate(dateStr: string): string {
  const dt = parseLocalDate(dateStr);
  const utc = new Date(Date.UTC(dt.getFullYear(), dt.getMonth(), dt.getDate()));
  const dayNum = utc.getUTCDay() || 7;
  utc.setUTCDate(utc.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(utc.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((utc.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${utc.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

export function getMondayDateFromWeekKey(weekKey: string): Date {
  const match = weekKey.match(/^(\d{4})-W(\d{2})$/);
  if (!match) return getMondayOfDate(getTodayDateStr());
  const year = Number.parseInt(match[1], 10);
  const week = Number.parseInt(match[2], 10);
  const jan4 = new Date(Date.UTC(year, 0, 4));
  const jan4Day = jan4.getUTCDay() || 7;
  const week1Monday = new Date(jan4);
  week1Monday.setUTCDate(jan4.getUTCDate() - (jan4Day - 1));
  const targetMonday = new Date(week1Monday);
  targetMonday.setUTCDate(week1Monday.getUTCDate() + (week - 1) * 7);
  return new Date(
    targetMonday.getUTCFullYear(),
    targetMonday.getUTCMonth(),
    targetMonday.getUTCDate(),
  );
}

export function getWeekDates(weekKey: string): Array<{
  key: WeekDayKey;
  label: string;
  shortLabel: string;
  dateStr: string;
  dayMonthLabel: string;
}> {
  const monday = getMondayDateFromWeekKey(weekKey);
  return WEEK_DAYS.map((wd) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + wd.offset);
    const dateStr = toDateStr(d);
    const monthShort = MONTH_SHORT_ID[d.getMonth()] ?? '';
    return {
      key: wd.key,
      label: wd.label,
      shortLabel: wd.shortLabel,
      dateStr,
      dayMonthLabel: `${d.getDate()} ${monthShort}`,
    };
  });
}

export function getWeekDayKeyFromDate(dateStr: string): WeekDayKey {
  const dt = parseLocalDate(dateStr);
  const day = dt.getDay(); // 0=Sun..6=Sat
  const map: Record<number, WeekDayKey> = {
    1: 'mon',
    2: 'tue',
    3: 'wed',
    4: 'thu',
    5: 'fri',
    6: 'sat',
    0: 'sun',
  };
  return map[day] ?? 'mon';
}

export function shiftWeekKey(weekKey: string, deltaWeeks: number): string {
  const monday = getMondayDateFromWeekKey(weekKey);
  monday.setDate(monday.getDate() + deltaWeeks * 7);
  return getIsoWeekKeyFromDate(toDateStr(monday));
}

const MONTH_NAMES_ID = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

const MONTH_SHORT_ID = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'Mei',
  'Jun',
  'Jul',
  'Agu',
  'Sep',
  'Okt',
  'Nov',
  'Des',
];

export function formatWeekLabel(weekKey: string): string {
  const dates = getWeekDates(weekKey);
  if (dates.length !== 7) return weekKey;
  return `${dates[0].dayMonthLabel} – ${dates[6].dayMonthLabel} (${weekKey})`;
}

export function formatDateID(dateStr: string): string {
  const [yStr, mStr, dStr] = dateStr.split('-');
  const m = Number.parseInt(mStr, 10);
  const d = Number.parseInt(dStr, 10);
  if (!yStr || !m || !d) return dateStr;
  return `${d} ${MONTH_NAMES_ID[m - 1] ?? mStr} ${yStr}`;
}

export function formatIDR(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(amount || 0);
}

export function toSafeId(raw: string): string {
  const normalized = raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return normalized.slice(0, 64) || `staff-${Date.now()}`;
}

export const SHIFT_META: Record<
  ShiftCode,
  { label: string; short: string; className: string }
> = {
  P: {
    label: 'Pagi',
    short: 'P',
    className: 'bg-sky-100 text-sky-800 border-sky-200',
  },
  M: {
    label: 'Middle',
    short: 'M',
    className: 'bg-indigo-100 text-indigo-800 border-indigo-200',
  },
  S: {
    label: 'Siang',
    short: 'S',
    className: 'bg-amber-100 text-amber-800 border-amber-200',
  },
  X: {
    label: 'Off / Libur',
    short: 'X',
    className: 'bg-slate-100 text-slate-500 border-slate-200',
  },
};

export function formatCashierWhatsAppText(
  report: Omit<
    CashierReport,
    'id' | 'createdAt' | 'updatedAt' | 'storeId' | 'monthKey' | 'weekKey'
  >,
  storeName: string,
): string {
  return [
    `*LAPORAN HARIAN KASIR — ${storeName.toUpperCase()}*`,
    `Tanggal: ${formatDateID(report.date)}`,
    `Shift: ${report.shift} | Kasir: ${report.cashierName}`,
    ``,
    `*1. Open Studio (OPS) Dilakukan*`,
    `• Total Sesi OPS: ${report.openStudioCount} sesi`,
    `• Total Peserta Open Studio: ${report.openStudioParticipants} orang`,
    ``,
    `*2. Try-on Produk Dilakukan (Total: ${report.totalTryOnCount} sesi)*`,
    `• AirPods: ${report.tryOnCounts.airpods} sesi`,
    `• iPad: ${report.tryOnCounts.ipad} sesi`,
    `• Apple Watch: ${report.tryOnCounts.watch} sesi`,
    ``,
    `*3. Catatan Shift / Serah Terima*`,
    `${report.handoverNotes || 'Operasional berjalan lancar.'}`,
  ].join('\n');
}
