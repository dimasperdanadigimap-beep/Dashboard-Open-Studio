import {
  StaffActivity,
  TargetQuotas,
  WeeklyStaffShift,
  WeeklyTargetConfig,
} from '../types/operations';
import { getWeekDates, getWeekDayKeyFromDate } from './formatters';

export const DEFAULT_DAILY_QUOTAS: TargetQuotas = {
  openStudio: 1,
  airpods: 2,
  ipad: 1,
  watch: 1,
};

export const DEFAULT_MANUAL_TOTALS: TargetQuotas = {
  openStudio: 30,
  airpods: 60,
  ipad: 30,
  watch: 30,
};

export interface ComputedTargetSummary {
  mode: 'auto' | 'manual';
  totalActiveShifts: number;
  targets: TargetQuotas;
  actuals: TargetQuotas;
  percentages: TargetQuotas;
}

export function computeWeeklyTargetsAndActuals(
  staffRoster: WeeklyStaffShift[],
  activities: StaffActivity[],
  targetConfig: WeeklyTargetConfig | null,
  weekKey: string,
): ComputedTargetSummary {
  const weekActivities = activities.filter((a) => a.weekKey === weekKey);
  const totalActiveShifts = staffRoster.reduce((acc, s) => acc + s.totalActiveDays, 0);

  const mode = targetConfig?.mode ?? 'auto';
  const dailyQuotas = targetConfig?.dailyQuotas ?? DEFAULT_DAILY_QUOTAS;

  let targets: TargetQuotas;
  if (mode === 'manual' && targetConfig) {
    targets = {
      openStudio: targetConfig.manualTotals.openStudio,
      airpods: targetConfig.manualTotals.airpods,
      ipad: targetConfig.manualTotals.ipad,
      watch: targetConfig.manualTotals.watch,
    };
  } else {
    targets = {
      openStudio: Math.round(totalActiveShifts * dailyQuotas.openStudio),
      airpods: Math.round(totalActiveShifts * dailyQuotas.airpods),
      ipad: Math.round(totalActiveShifts * dailyQuotas.ipad),
      watch: Math.round(totalActiveShifts * dailyQuotas.watch),
    };
  }

  const actuals: TargetQuotas = {
    openStudio: weekActivities.filter((a) => a.activityType === 'open_studio').length,
    airpods: weekActivities.filter(
      (a) => a.activityType === 'try_on' && a.productCategory === 'AirPods',
    ).length,
    ipad: weekActivities.filter(
      (a) => a.activityType === 'try_on' && a.productCategory === 'iPad',
    ).length,
    watch: weekActivities.filter(
      (a) => a.activityType === 'try_on' && a.productCategory === 'Apple Watch',
    ).length,
  };

  const pct = (actual: number, target: number) =>
    target > 0 ? Math.min(999, Math.round((actual / target) * 100)) : 0;

  return {
    mode,
    totalActiveShifts,
    targets,
    actuals,
    percentages: {
      openStudio: pct(actuals.openStudio, targets.openStudio),
      airpods: pct(actuals.airpods, targets.airpods),
      ipad: pct(actuals.ipad, targets.ipad),
      watch: pct(actuals.watch, targets.watch),
    },
  };
}

export interface ActiveShiftStaffItem {
  staff: WeeklyStaffShift;
  shiftCode: 'P' | 'M' | 'S';
  activitiesToday: StaffActivity[];
}

export function getActiveStaffForDate(
  staffRoster: WeeklyStaffShift[],
  activities: StaffActivity[],
  dateStr: string,
): ActiveShiftStaffItem[] {
  const dayKey = getWeekDayKeyFromDate(dateStr);
  const result: ActiveShiftStaffItem[] = [];

  for (const staff of staffRoster) {
    const code = staff.shifts[dayKey];
    if (code === 'P' || code === 'M' || code === 'S') {
      const acts = activities.filter(
        (a) => a.date === dateStr && a.staffId === staff.staffId,
      );
      result.push({
        staff,
        shiftCode: code,
        activitiesToday: acts,
      });
    }
  }

  return result.sort((a, b) => a.staff.name.localeCompare(b.staff.name));
}

export interface StaffComplianceRow {
  staffId: string;
  name: string;
  role: string;
  totalActiveDays: number;
  activeLoggedDays: number;
  complianceRate: number;
  openStudioCount: number;
  airpodsCount: number;
  ipadCount: number;
  watchCount: number;
  totalActivities: number;
  targetTotal: number;
}

export function computeWeeklyStaffCompliance(
  staffRoster: WeeklyStaffShift[],
  activities: StaffActivity[],
  targetConfig: WeeklyTargetConfig | null,
  weekKey: string,
): StaffComplianceRow[] {
  const weekActivities = activities.filter((a) => a.weekKey === weekKey);
  const dailyQuotas = targetConfig?.dailyQuotas ?? DEFAULT_DAILY_QUOTAS;
  const quotaSumPerShift =
    dailyQuotas.openStudio + dailyQuotas.airpods + dailyQuotas.ipad + dailyQuotas.watch;

  return staffRoster
    .map((staff) => {
      const staffActs = weekActivities.filter((a) => a.staffId === staff.staffId);
      const loggedActiveDates = new Set<string>();

      for (const act of staffActs) {
        const dayKey = getWeekDayKeyFromDate(act.date);
        const shift = staff.shifts[dayKey];
        if (shift === 'P' || shift === 'M' || shift === 'S') {
          loggedActiveDates.add(act.date);
        }
      }

      const activeLoggedDays = loggedActiveDates.size;
      const complianceRate =
        staff.totalActiveDays > 0
          ? Math.round((activeLoggedDays / staff.totalActiveDays) * 100)
          : 0;

      const openStudioCount = staffActs.filter((a) => a.activityType === 'open_studio').length;
      const airpodsCount = staffActs.filter(
        (a) => a.activityType === 'try_on' && a.productCategory === 'AirPods',
      ).length;
      const ipadCount = staffActs.filter(
        (a) => a.activityType === 'try_on' && a.productCategory === 'iPad',
      ).length;
      const watchCount = staffActs.filter(
        (a) => a.activityType === 'try_on' && a.productCategory === 'Apple Watch',
      ).length;

      const override = targetConfig?.staffOverrides?.[staff.staffId];
      const targetTotal = override
        ? override.openStudio + override.airpods + override.ipad + override.watch
        : Math.round(staff.totalActiveDays * quotaSumPerShift);

      return {
        staffId: staff.staffId,
        name: staff.name,
        role: staff.role,
        totalActiveDays: staff.totalActiveDays,
        activeLoggedDays,
        complianceRate,
        openStudioCount,
        airpodsCount,
        ipadCount,
        watchCount,
        totalActivities: staffActs.length,
        targetTotal,
      };
    })
    .sort((a, b) => b.complianceRate - a.complianceRate || a.name.localeCompare(b.name));
}

export interface WeeklySeriesPoint {
  dayLabel: string;
  shortLabel: string;
  dayMonthLabel: string;
  dateStr: string;
  openStudio: number;
  tryOn: number;
}

export function computeWeeklyActivitySeries(
  activities: StaffActivity[],
  weekKey: string,
): WeeklySeriesPoint[] {
  const days = getWeekDates(weekKey);
  const weekActivities = activities.filter((a) => a.weekKey === weekKey);

  return days.map((d) => {
    const dayActs = weekActivities.filter((a) => a.date === d.dateStr);
    return {
      dayLabel: d.label,
      shortLabel: d.shortLabel,
      dayMonthLabel: d.dayMonthLabel,
      dateStr: d.dateStr,
      openStudio: dayActs.filter((a) => a.activityType === 'open_studio').length,
      tryOn: dayActs.filter((a) => a.activityType === 'try_on').length,
    };
  });
}
