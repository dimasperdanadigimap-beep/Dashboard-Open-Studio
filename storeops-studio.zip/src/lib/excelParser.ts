import * as XLSX from 'xlsx';
import {
  CashierReport,
  ShiftCode,
  ShiftCounts,
  StaffActivity,
  WeekDayKey,
  WeeklyStaffShift,
} from '../types/operations';
import {
  formatWeekLabel,
  getWeekDates,
  toSafeId,
  WEEK_DAYS,
} from './formatters';

function normalizeShiftCode(raw: unknown): ShiftCode {
  const val = String(raw ?? '')
    .trim()
    .toUpperCase();
  if (val === 'P' || val === 'PAGI') return 'P';
  if (val === 'M' || val === 'MID' || val === 'MIDDLE') return 'M';
  if (val === 'S' || val === 'SIANG' || val === 'SORE') return 'S';
  return 'X';
}

function matchWeekDayHeader(header: string): WeekDayKey | null {
  const h = header.trim().toLowerCase();
  if (/^(senin|sen|monday|mon|1)$/.test(h)) return 'mon';
  if (/^(selasa|sel|tuesday|tue|2)$/.test(h)) return 'tue';
  if (/^(rabu|rab|wednesday|wed|3)$/.test(h)) return 'wed';
  if (/^(kamis|kam|thursday|thu|4)$/.test(h)) return 'thu';
  if (/^(jumat|jum'at|jum|friday|fri|5)$/.test(h)) return 'fri';
  if (/^(sabtu|sab|saturday|sat|6)$/.test(h)) return 'sat';
  if (/^(minggu|min|ahad|sunday|sun|7)$/.test(h)) return 'sun';
  return null;
}

export interface ParsedWeeklyScheduleResult {
  weekKey: string;
  weekLabel: string;
  startDate: string;
  endDate: string;
  records: Omit<WeeklyStaffShift, 'updatedAt'>[];
  totalActiveShifts: number;
}

export async function parseWeeklyScheduleWorkbook(
  file: File,
  weekKey: string,
): Promise<ParsedWeeklyScheduleResult> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });
  const firstSheetName = workbook.SheetNames[0];
  if (!firstSheetName) {
    throw new Error('File Excel tidak memiliki worksheet.');
  }

  const sheet = workbook.Sheets[firstSheetName];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
    defval: '',
  });

  if (rows.length === 0) {
    throw new Error('Worksheet kosong. Pastikan ada baris header dan data staff.');
  }

  const headers = Object.keys(rows[0]);
  const nameKey =
    headers.find((h) => /nama|name|staff|karyawan/i.test(h)) ?? headers[0];
  const roleKey = headers.find((h) => /jabatan|role|posisi|divisi/i.test(h));

  const dayColumnMap: Partial<Record<WeekDayKey, string>> = {};
  for (const h of headers) {
    const matched = matchWeekDayHeader(h);
    if (matched) {
      dayColumnMap[matched] = h;
    }
  }

  if (Object.keys(dayColumnMap).length === 0) {
    throw new Error(
      'Kolom hari Senin–Minggu tidak ditemukan. Gunakan header: Senin, Selasa, Rabu, Kamis, Jumat, Sabtu, Minggu.',
    );
  }

  const weekDates = getWeekDates(weekKey);
  const records: Omit<WeeklyStaffShift, 'updatedAt'>[] = [];
  let totalActiveShifts = 0;

  for (const row of rows) {
    const rawName = String(row[nameKey] ?? '').trim();
    if (!rawName || /^total$/i.test(rawName)) continue;

    const role = roleKey
      ? String(row[roleKey] ?? '').trim() || 'Store Specialist'
      : 'Store Specialist';

    const shifts: Record<WeekDayKey, ShiftCode> = {
      mon: 'X',
      tue: 'X',
      wed: 'X',
      thu: 'X',
      fri: 'X',
      sat: 'X',
      sun: 'X',
    };
    const counts: ShiftCounts = { P: 0, M: 0, S: 0, X: 0 };

    for (const wd of WEEK_DAYS) {
      const colHeader = dayColumnMap[wd.key];
      const code = colHeader ? normalizeShiftCode(row[colHeader]) : 'X';
      shifts[wd.key] = code;
      counts[code] += 1;
    }

    const totalActiveDays = counts.P + counts.M + counts.S;
    totalActiveShifts += totalActiveDays;

    records.push({
      storeId: 'store-main',
      weekKey,
      staffId: toSafeId(rawName),
      name: rawName.slice(0, 120),
      role: role.slice(0, 80),
      shifts,
      totalActiveDays,
      counts,
    });
  }

  if (records.length === 0) {
    throw new Error('Tidak ada data nama staff yang valid di dalam file.');
  }

  return {
    weekKey,
    weekLabel: formatWeekLabel(weekKey),
    startDate: weekDates[0].dateStr,
    endDate: weekDates[6].dateStr,
    records,
    totalActiveShifts,
  };
}

export function generateSampleWeeklySchedule(
  weekKey: string,
): ParsedWeeklyScheduleResult {
  const sampleStaff = [
    { name: 'Andi Pratama', role: 'Apple Specialist' },
    { name: 'Nadia Kusuma', role: 'Creative Trainer' },
    { name: 'Rizky Hidayat', role: 'Apple Specialist' },
    { name: 'Clarissa Wijaya', role: 'Senior Specialist' },
    { name: 'Bagas Saputra', role: 'Apple Specialist' },
    { name: 'Sinta Dewi', role: 'Cashier & Admin' },
    { name: 'Fajar Ramadhan', role: 'Apple Specialist' },
    { name: 'Michelle Tan', role: 'Creative Trainer' },
  ];

  const patternPool: ShiftCode[] = ['P', 'M', 'S', 'P', 'M', 'S', 'X'];
  const weekDates = getWeekDates(weekKey);
  let totalActiveShifts = 0;

  const records: Omit<WeeklyStaffShift, 'updatedAt'>[] = sampleStaff.map(
    (person, idx) => {
      const shifts: Record<WeekDayKey, ShiftCode> = {
        mon: 'X',
        tue: 'X',
        wed: 'X',
        thu: 'X',
        fri: 'X',
        sat: 'X',
        sun: 'X',
      };
      const counts: ShiftCounts = { P: 0, M: 0, S: 0, X: 0 };

      WEEK_DAYS.forEach((wd, dayIdx) => {
        const code = patternPool[(dayIdx + idx * 2) % patternPool.length];
        shifts[wd.key] = code;
        counts[code] += 1;
      });

      const totalActiveDays = counts.P + counts.M + counts.S;
      totalActiveShifts += totalActiveDays;

      return {
        storeId: 'store-main',
        weekKey,
        staffId: toSafeId(person.name),
        name: person.name,
        role: person.role,
        shifts,
        totalActiveDays,
        counts,
      };
    },
  );

  return {
    weekKey,
    weekLabel: formatWeekLabel(weekKey),
    startDate: weekDates[0].dateStr,
    endDate: weekDates[6].dateStr,
    records,
    totalActiveShifts,
  };
}

export function downloadWeeklyTemplateExcel(weekKey: string) {
  const sample = generateSampleWeeklySchedule(weekKey);
  const headerRow = [
    'Nama Staff',
    'Jabatan',
    'Senin',
    'Selasa',
    'Rabu',
    'Kamis',
    'Jumat',
    'Sabtu',
    'Minggu',
  ];

  const dataRows = sample.records.map((rec) => [
    rec.name,
    rec.role,
    rec.shifts.mon,
    rec.shifts.tue,
    rec.shifts.wed,
    rec.shifts.thu,
    rec.shifts.fri,
    rec.shifts.sat,
    rec.shifts.sun,
  ]);

  const ws = XLSX.utils.aoa_to_sheet([headerRow, ...dataRows]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Jadwal_Mingguan');
  XLSX.writeFile(wb, `Template_Jadwal_Mingguan_${weekKey}.xlsx`);
}

export interface StaffComplianceExportRow {
  name: string;
  role: string;
  totalActiveDays: number;
  activeLoggedDays: number;
  complianceRate: number;
  openStudioCount: number;
  airpodsCount: number;
  ipadCount: number;
  watchCount: number;
}

export function exportOperationsReportExcel(params: {
  weekKey: string;
  storeName: string;
  activities: StaffActivity[];
  complianceRows: StaffComplianceExportRow[];
  cashierReports: CashierReport[];
}) {
  const wb = XLSX.utils.book_new();

  const activityRows = params.activities.map((a) => ({
    Tanggal: a.date,
    Minggu: a.weekKey,
    'Nama Staff': a.staffName,
    Jabatan: a.staffRole,
    Shift: a.shiftCode,
    'Jenis Aktivitas': a.activityType === 'open_studio' ? 'Open Studio' : 'Try-on Produk',
    'Topik / Kategori': a.activityType === 'open_studio' ? a.topic : a.productCategory,
    'Jumlah Peserta': a.activityType === 'open_studio' ? a.participantsCount : 1,
    'Catatan Customer': a.customerNotes || '-',
    'Link Foto (Google Drive)': a.photoUrl || '-',
  }));
  const wsActivities = XLSX.utils.json_to_sheet(
    activityRows.length > 0
      ? activityRows
      : [{ Info: 'Belum ada log aktivitas pada minggu ini.' }],
  );
  XLSX.utils.book_append_sheet(wb, wsActivities, 'Log_Aktivitas');

  const complianceSheetRows = params.complianceRows.map((c) => ({
    'Nama Staff': c.name,
    Jabatan: c.role,
    'Shift Aktif (Sen-Min)': c.totalActiveDays,
    'Hari Ada Aktivitas': c.activeLoggedDays,
    'Compliance Rate (%)': `${c.complianceRate}%`,
    'Open Studio': c.openStudioCount,
    'Try-on AirPods': c.airpodsCount,
    'Try-on iPad': c.ipadCount,
    'Try-on Apple Watch': c.watchCount,
  }));
  const wsCompliance = XLSX.utils.json_to_sheet(
    complianceSheetRows.length > 0
      ? complianceSheetRows
      : [{ Info: 'Belum ada data jadwal staff minggu ini.' }],
  );
  XLSX.utils.book_append_sheet(wb, wsCompliance, 'Audit_Kepatuhan');

  const cashierSheetRows = params.cashierReports.map((r) => ({
    Tanggal: r.date,
    Shift: r.shift,
    'Nama Kasir': r.cashierName,
    'OPS / Open Studio (Sesi)': r.openStudioCount,
    'Peserta Open Studio': r.openStudioParticipants,
    'Total Try-on (Sesi)': r.totalTryOnCount,
    'Try-on AirPods': r.tryOnCounts.airpods,
    'Try-on iPad': r.tryOnCounts.ipad,
    'Try-on Apple Watch': r.tryOnCounts.watch,
    'Catatan Shift': r.handoverNotes || '-',
  }));
  const wsCashier = XLSX.utils.json_to_sheet(
    cashierSheetRows.length > 0
      ? cashierSheetRows
      : [{ Info: 'Belum ada laporan kasir pada minggu ini.' }],
  );
  XLSX.utils.book_append_sheet(wb, wsCashier, 'Laporan_Kasir');

  XLSX.writeFile(
    wb,
    `StoreOps_Weekly_${params.storeName.replace(/\s+/g, '_')}_${params.weekKey}.xlsx`,
  );
}
