import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Copy,
  Download,
  FileSpreadsheet,
  FolderOpen,
  Lock,
  Receipt,
  RefreshCw,
  Save,
  Sparkles,
  Trash2,
  Unlock,
  UploadCloud,
  Wifi,
} from 'lucide-react';
import {
  computeWeeklyStaffCompliance,
  computeWeeklyTargetsAndActuals,
  DEFAULT_DAILY_QUOTAS,
  DEFAULT_MANUAL_TOTALS,
} from '../lib/analytics';
import {
  GOOGLE_APPS_SCRIPT_TEMPLATE,
  testDriveAppsScriptConnection,
} from '../lib/driveUploader';
import {
  downloadWeeklyTemplateExcel,
  exportOperationsReportExcel,
  parseWeeklyScheduleWorkbook,
} from '../lib/excelParser';
import {
  formatCashierWhatsAppText,
  formatDateID,
  formatWeekLabel,
  getIsoWeekKeyFromDate,
} from '../lib/formatters';
import {
  CashierReport,
  CashierTryOnCounts,
  DriveFolderMap,
  StaffActivity,
  StoreSettings,
  SurveyLinkMap,
  TargetMode,
  TargetQuotas,
  WeeklyStaffShift,
  WeeklyTargetConfig,
} from '../types/operations';

export type AdminSubTab = 'cashier' | 'schedule_target' | 'integration';

interface AdminAndCashierViewProps {
  activeSubTab: AdminSubTab;
  onChangeSubTab: (tab: AdminSubTab) => void;
  adminUnlocked: boolean;
  onUnlockAdmin: (password: string) => boolean;
  onLockAdmin: () => void;
  weekKey: string;
  selectedDate: string;
  storeSettings: StoreSettings;
  staffRoster: WeeklyStaffShift[];
  targetConfig: WeeklyTargetConfig | null;
  activities: StaffActivity[];
  cashierReports: CashierReport[];
  onSaveStoreSettings: (
    next: Pick<StoreSettings, 'storeName' | 'driveScriptUrl' | 'driveFolders' | 'surveyLinks'>,
  ) => Promise<void>;
  onUploadParsedSchedule: (
    parsed: Awaited<ReturnType<typeof parseWeeklyScheduleWorkbook>>,
    fileName: string,
  ) => Promise<void>;
  onLoadSampleSchedule: () => Promise<void>;
  onSaveTargetConfig: (
    next: Omit<WeeklyTargetConfig, 'storeId' | 'updatedAt'>,
  ) => Promise<void>;
  onCreateCashierReport: (
    payload: Omit<CashierReport, 'id' | 'storeId' | 'createdAt' | 'updatedAt'>,
  ) => Promise<void>;
  onDeleteCashierReport: (reportId: string) => Promise<void>;
}

export const AdminAndCashierView: React.FC<AdminAndCashierViewProps> = ({
  activeSubTab,
  onChangeSubTab,
  adminUnlocked,
  onUnlockAdmin,
  onLockAdmin,
  weekKey,
  selectedDate,
  storeSettings,
  staffRoster,
  targetConfig,
  activities,
  cashierReports,
  onSaveStoreSettings,
  onUploadParsedSchedule,
  onLoadSampleSchedule,
  onSaveTargetConfig,
  onCreateCashierReport,
  onDeleteCashierReport,
}) => {
  // --- Admin Password Gate State ---
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);
    const ok = onUnlockAdmin(passwordInput);
    if (!ok) {
      setPasswordError('Password Admin salah. Masukkan password yang benar.');
    } else {
      setPasswordInput('');
    }
  };

  // --- Live OPS & Try-on Summary from Activity Logs ---
  const liveDailyOpsAndTryOn = useMemo(() => {
    const dayLogs = activities.filter((a) => a.date === selectedDate);
    let openStudioCount = 0;
    let openStudioParticipants = 0;
    const tryOnCounts: CashierTryOnCounts = { airpods: 0, ipad: 0, watch: 0 };

    for (const act of dayLogs) {
      if (act.activityType === 'open_studio') {
        openStudioCount += 1;
        openStudioParticipants += act.participantsCount || 0;
      } else {
        if (act.productCategory === 'AirPods') tryOnCounts.airpods += 1;
        else if (act.productCategory === 'iPad') tryOnCounts.ipad += 1;
        else if (act.productCategory === 'Apple Watch') tryOnCounts.watch += 1;
      }
    }

    return {
      openStudioCount,
      openStudioParticipants,
      tryOnCounts,
      totalTryOnCount: tryOnCounts.airpods + tryOnCounts.ipad + tryOnCounts.watch,
    };
  }, [activities, selectedDate]);

  const liveWeeklyOpsAndTryOn = useMemo(() => {
    const weekLogs = activities.filter((a) => a.weekKey === weekKey);
    let openStudioCount = 0;
    let tryOnTotal = 0;
    for (const act of weekLogs) {
      if (act.activityType === 'open_studio') openStudioCount += 1;
      else tryOnTotal += 1;
    }
    return { openStudioCount, tryOnTotal };
  }, [activities, weekKey]);

  // --- Cashier Report State (OPS & Try-on only, no Revenue) ---
  const [cashierShift, setCashierShift] = useState<CashierReport['shift']>('Full Day');
  const [cashierName, setCashierName] = useState('');
  const [openStudioCount, setOpenStudioCount] = useState<number>(
    liveDailyOpsAndTryOn.openStudioCount,
  );
  const [openStudioParticipants, setOpenStudioParticipants] = useState<number>(
    liveDailyOpsAndTryOn.openStudioParticipants,
  );
  const [tryOnCounts, setTryOnCounts] = useState<CashierTryOnCounts>(
    liveDailyOpsAndTryOn.tryOnCounts,
  );
  const [handoverNotes, setHandoverNotes] = useState('');
  const [savingCashier, setSavingCashier] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [cashierFeedback, setCashierFeedback] = useState<string | null>(null);

  const syncFromDailyLogs = () => {
    setOpenStudioCount(liveDailyOpsAndTryOn.openStudioCount);
    setOpenStudioParticipants(liveDailyOpsAndTryOn.openStudioParticipants);
    setTryOnCounts({ ...liveDailyOpsAndTryOn.tryOnCounts });
  };

  useEffect(() => {
    setOpenStudioCount(liveDailyOpsAndTryOn.openStudioCount);
    setOpenStudioParticipants(liveDailyOpsAndTryOn.openStudioParticipants);
    setTryOnCounts({ ...liveDailyOpsAndTryOn.tryOnCounts });
  }, [liveDailyOpsAndTryOn]);

  const totalTryOnCount =
    tryOnCounts.airpods + tryOnCounts.ipad + tryOnCounts.watch;

  const liveWaText = useMemo(
    () =>
      formatCashierWhatsAppText(
        {
          date: selectedDate,
          shift: cashierShift,
          cashierName: cashierName || 'Kasir',
          openStudioCount,
          openStudioParticipants,
          tryOnCounts,
          totalTryOnCount,
          handoverNotes,
        },
        storeSettings.storeName,
      ),
    [
      selectedDate,
      cashierShift,
      cashierName,
      openStudioCount,
      openStudioParticipants,
      tryOnCounts,
      totalTryOnCount,
      handoverNotes,
      storeSettings.storeName,
    ],
  );

  const handleCopyText = async (text: string, id: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleCashierSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCashierFeedback(null);
    setSavingCashier(true);
    try {
      await onCreateCashierReport({
        date: selectedDate,
        weekKey: getIsoWeekKeyFromDate(selectedDate),
        monthKey: selectedDate.slice(0, 7),
        shift: cashierShift,
        cashierName: cashierName.trim() || 'Kasir',
        openStudioCount,
        openStudioParticipants,
        tryOnCounts,
        totalTryOnCount,
        handoverNotes: handoverNotes.trim(),
      });
      setCashierFeedback('Laporan operasional kasir (OPS & Try-on) berhasil disimpan.');
      setHandoverNotes('');
    } finally {
      setSavingCashier(false);
    }
  };

  const complianceRows = useMemo(
    () => computeWeeklyStaffCompliance(staffRoster, activities, targetConfig, weekKey),
    [staffRoster, activities, targetConfig, weekKey],
  );

  // --- Schedule & Targets State ---
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [uploadingExcel, setUploadingExcel] = useState(false);
  const [excelStatus, setExcelStatus] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null,
  );

  const [targetMode, setTargetMode] = useState<TargetMode>(targetConfig?.mode ?? 'auto');
  const [dailyQuotas, setDailyQuotas] = useState<TargetQuotas>(
    targetConfig?.dailyQuotas ?? DEFAULT_DAILY_QUOTAS,
  );
  const [manualTotals, setManualTotals] = useState<TargetQuotas>(
    targetConfig?.manualTotals ?? DEFAULT_MANUAL_TOTALS,
  );
  const [staffOverrides, setStaffOverrides] = useState<Record<string, TargetQuotas>>(
    targetConfig?.staffOverrides ?? {},
  );
  const [savingTargets, setSavingTargets] = useState(false);
  const [targetMessage, setTargetMessage] = useState<string | null>(null);

  useEffect(() => {
    setTargetMode(targetConfig?.mode ?? 'auto');
    setDailyQuotas(targetConfig?.dailyQuotas ?? DEFAULT_DAILY_QUOTAS);
    setManualTotals(targetConfig?.manualTotals ?? DEFAULT_MANUAL_TOTALS);
    setStaffOverrides(targetConfig?.staffOverrides ?? {});
  }, [targetConfig]);

  const computedPreview = useMemo(
    () =>
      computeWeeklyTargetsAndActuals(
        staffRoster,
        activities,
        {
          storeId: 'store-main',
          weekKey,
          mode: targetMode,
          dailyQuotas,
          manualTotals,
          staffOverrides,
        },
        weekKey,
      ),
    [staffRoster, activities, weekKey, targetMode, dailyQuotas, manualTotals, staffOverrides],
  );

  const handleExcelFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setExcelStatus(null);
    setUploadingExcel(true);
    try {
      const parsed = await parseWeeklyScheduleWorkbook(file, weekKey);
      await onUploadParsedSchedule(parsed, file.name);
      setExcelStatus({
        type: 'success',
        text: `Berhasil mengimpor ${parsed.records.length} staff (${parsed.totalActiveShifts} total shift aktif P/M/S) untuk ${parsed.weekLabel}.`,
      });
    } catch (err) {
      setExcelStatus({
        type: 'error',
        text: err instanceof Error ? err.message : 'Gagal memproses file Excel.',
      });
    } finally {
      setUploadingExcel(false);
      e.target.value = '';
    }
  };

  const handleSaveTargets = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingTargets(true);
    setTargetMessage(null);
    try {
      await onSaveTargetConfig({
        weekKey,
        mode: targetMode,
        dailyQuotas,
        manualTotals,
        staffOverrides,
      });
      setTargetMessage('Pengaturan target mingguan berhasil disimpan.');
    } finally {
      setSavingTargets(false);
    }
  };

  const updateStaffOverrideField = (
    staffId: string,
    field: keyof TargetQuotas,
    val: number,
  ) => {
    setStaffOverrides((prev) => {
      const current = prev[staffId] || {
        openStudio: 0,
        airpods: 0,
        ipad: 0,
        watch: 0,
      };
      return {
        ...prev,
        [staffId]: {
          ...current,
          [field]: Math.max(0, val),
        },
      };
    });
  };

  // --- Store & Drive Integration State ---
  const [storeNameInput, setStoreNameInput] = useState(storeSettings.storeName);
  const [driveScriptUrlInput, setDriveScriptUrlInput] = useState(storeSettings.driveScriptUrl);
  const [driveFoldersInput, setDriveFoldersInput] = useState<DriveFolderMap>(
    storeSettings.driveFolders,
  );
  const [surveyLinksInput, setSurveyLinksInput] = useState<SurveyLinkMap>(
    storeSettings.surveyLinks,
  );
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsSavedMsg, setSettingsSavedMsg] = useState<string | null>(null);
  const [testingBridge, setTestingBridge] = useState(false);
  const [bridgeTestResult, setBridgeTestResult] = useState<{
    ok: boolean;
    text: string;
  } | null>(null);

  useEffect(() => {
    setStoreNameInput(storeSettings.storeName);
    setDriveScriptUrlInput(storeSettings.driveScriptUrl);
    setDriveFoldersInput(storeSettings.driveFolders);
    setSurveyLinksInput(storeSettings.surveyLinks);
  }, [storeSettings]);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    setSettingsSavedMsg(null);
    try {
      await onSaveStoreSettings({
        storeName: storeNameInput,
        driveScriptUrl: driveScriptUrlInput,
        driveFolders: driveFoldersInput,
        surveyLinks: surveyLinksInput,
      });
      setSettingsSavedMsg('Konfigurasi toko, 4 folder Google Drive & link survey tersimpan online.');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleTestBridge = async () => {
    setTestingBridge(true);
    setBridgeTestResult(null);
    try {
      const msg = await testDriveAppsScriptConnection(driveScriptUrlInput);
      setBridgeTestResult({ ok: true, text: msg });
    } catch (err) {
      setBridgeTestResult({
        ok: false,
        text: err instanceof Error ? err.message : 'Gagal terhubung ke GAS Web App.',
      });
    } finally {
      setTestingBridge(false);
    }
  };

  const handleExportFullExcel = () => {
    exportOperationsReportExcel({
      weekKey,
      storeName: storeSettings.storeName,
      activities: activities.filter((a) => a.weekKey === weekKey),
      complianceRows,
      cashierReports: cashierReports.filter((r) => r.weekKey === weekKey),
    });
  };

  const isProtectedAdminTab = activeSubTab !== 'cashier';

  return (
    <div className="space-y-6">
      {/* Sub-navigation bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl p-2">
        <div className="flex flex-wrap items-center gap-1">
          {[
            { id: 'cashier' as AdminSubTab, label: 'Laporan Kasir', locked: false },
            { id: 'schedule_target' as AdminSubTab, label: 'Jadwal & Target', locked: !adminUnlocked },
            { id: 'integration' as AdminSubTab, label: 'Google Drive & Deploy', locked: !adminUnlocked },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => onChangeSubTab(tab.id)}
              className={`min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                activeSubTab === tab.id
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {tab.locked && <Lock className="w-3.5 h-3.5 opacity-75" />}
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {adminUnlocked && (
            <button
              type="button"
              onClick={onLockAdmin}
              className="min-h-[40px] inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors whitespace-nowrap"
            >
              <Unlock className="w-3.5 h-3.5" />
              Kunci Admin
            </button>
          )}
          <button
            type="button"
            onClick={handleExportFullExcel}
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Export Excel
          </button>
        </div>
      </div>

      {/* ADMIN PASSWORD GATE */}
      {isProtectedAdminTab && !adminUnlocked ? (
        <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-10 max-w-md mx-auto">
          <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center mb-4">
            <Lock className="w-5 h-5" />
          </div>
          <h2 className="text-lg font-semibold text-slate-900">
            Akses Terkunci — Khusus Admin
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Masukkan password Admin untuk membuka Upload Jadwal Mingguan, Target Mingguan,
            dan Konfigurasi Google Drive &amp; Survey.
          </p>

          <form onSubmit={handlePasswordSubmit} className="mt-5 space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Password Admin
              </label>
              <input
                type="password"
                required
                autoFocus
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Masukkan password Admin"
                className="w-full min-h-[44px] px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>

            {passwordError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs">
                {passwordError}
              </div>
            )}

            <button
              type="submit"
              className="w-full min-h-[44px] px-4 py-2.5 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
            >
              Buka Panel Admin
            </button>
          </form>
        </section>
      ) : (
        <>
          {/* SUB-TAB 1: CASHIER DAILY REPORT — OPS & TRY-ON SUMMARY (OPEN ACCESS) */}
          {activeSubTab === 'cashier' && (
            <div className="space-y-6">
              {/* Live Real-time OPS & Try-on Counters for Selected Date */}
              <section className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="bg-white border border-slate-200 rounded-xl p-4">
                  <p className="text-xs text-slate-500">OPS / Open Studio</p>
                  <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
                    {liveDailyOpsAndTryOn.openStudioCount} sesi
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5 tabular-nums">
                    {liveDailyOpsAndTryOn.openStudioParticipants} peserta · Minggu:{' '}
                    {liveWeeklyOpsAndTryOn.openStudioCount}
                  </p>
                </div>
                <div className="bg-white border border-slate-200 rounded-xl p-4">
                  <p className="text-xs text-slate-500">Total Try-on Hari Ini</p>
                  <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
                    {liveDailyOpsAndTryOn.totalTryOnCount} sesi
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5 tabular-nums">
                    Minggu ini: {liveWeeklyOpsAndTryOn.tryOnTotal} sesi
                  </p>
                </div>
                <div className="bg-white border border-slate-200 rounded-xl p-4">
                  <p className="text-xs text-slate-500">Try-on AirPods</p>
                  <p className="mt-1 font-mono text-xl font-semibold text-sky-700 tabular-nums">
                    {liveDailyOpsAndTryOn.tryOnCounts.airpods} sesi
                  </p>
                </div>
                <div className="bg-white border border-slate-200 rounded-xl p-4">
                  <p className="text-xs text-slate-500">Try-on iPad</p>
                  <p className="mt-1 font-mono text-xl font-semibold text-indigo-700 tabular-nums">
                    {liveDailyOpsAndTryOn.tryOnCounts.ipad} sesi
                  </p>
                </div>
                <div className="bg-white border border-slate-200 rounded-xl p-4 col-span-2 sm:col-span-1">
                  <p className="text-xs text-slate-500">Try-on Apple Watch</p>
                  <p className="mt-1 font-mono text-xl font-semibold text-amber-700 tabular-nums">
                    {liveDailyOpsAndTryOn.tryOnCounts.watch} sesi
                  </p>
                </div>
              </section>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <form
                  onSubmit={handleCashierSubmit}
                  className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5"
                >
                  <div className="pb-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h2 className="text-lg font-semibold text-slate-900">
                        Laporan Harian Kasir (OPS &amp; Try-on)
                      </h2>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {formatDateID(selectedDate)} · Rekap jumlah Open Studio (OPS) dan Try-on yang sudah dilakukan.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={syncFromDailyLogs}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Sinkronkan Log Hari Ini
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Shift Kasir
                      </label>
                      <select
                        value={cashierShift}
                        onChange={(e) => setCashierShift(e.target.value as CashierReport['shift'])}
                        className="w-full min-h-[42px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                      >
                        <option value="Full Day">Full Day (Tutup Toko)</option>
                        <option value="Pagi">Shift Pagi</option>
                        <option value="Middle">Shift Middle</option>
                        <option value="Siang">Shift Siang</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Nama Kasir Bertugas
                      </label>
                      <input
                        type="text"
                        required
                        value={cashierName}
                        onChange={(e) => setCashierName(e.target.value)}
                        placeholder="Masukkan nama kasir"
                        className="w-full min-h-[42px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                  </div>

                  {/* OPS / Open Studio Section */}
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-800">
                        OPS / Open Studio yang Sudah Dilakukan
                      </span>
                      <Receipt className="w-4 h-4 text-slate-400" />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-medium text-slate-600 mb-1">
                          Jumlah Sesi OPS / Open Studio
                        </label>
                        <input
                          type="number"
                          min={0}
                          value={openStudioCount}
                          onChange={(e) =>
                            setOpenStudioCount(Math.max(0, Number.parseInt(e.target.value, 10) || 0))
                          }
                          className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-medium text-slate-600 mb-1">
                          Total Peserta Open Studio
                        </label>
                        <input
                          type="number"
                          min={0}
                          value={openStudioParticipants}
                          onChange={(e) =>
                            setOpenStudioParticipants(
                              Math.max(0, Number.parseInt(e.target.value, 10) || 0),
                            )
                          }
                          className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Try-on Section */}
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-800">
                        Try-on Produk yang Sudah Dilakukan
                      </span>
                      <span className="font-mono text-xs font-semibold text-slate-900 tabular-nums">
                        Total: {totalTryOnCount} sesi
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      {[
                        { key: 'airpods', label: 'AirPods' },
                        { key: 'ipad', label: 'iPad' },
                        { key: 'watch', label: 'Apple Watch' },
                      ].map((cat) => (
                        <div key={cat.key}>
                          <label className="block text-[11px] font-medium text-slate-600 mb-1">
                            {cat.label}
                          </label>
                          <input
                            type="number"
                            min={0}
                            value={tryOnCounts[cat.key as keyof CashierTryOnCounts]}
                            onChange={(e) =>
                              setTryOnCounts((prev) => ({
                                ...prev,
                                [cat.key]: Math.max(0, Number.parseInt(e.target.value, 10) || 0),
                              }))
                            }
                            className="w-full min-h-[40px] px-3 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Catatan Shift / Handover Operasional
                    </label>
                    <textarea
                      rows={2}
                      maxLength={800}
                      value={handoverNotes}
                      onChange={(e) => setHandoverNotes(e.target.value)}
                      placeholder="Contoh: Semua unit demo AirPods, iPad, dan Apple Watch lengkap & rapi."
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                    />
                  </div>

                  {cashierFeedback && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm">
                      {cashierFeedback}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={savingCashier}
                    className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-60"
                  >
                    <Save className="w-4 h-4" />
                    {savingCashier ? 'Menyimpan...' : 'Simpan Laporan Kasir'}
                  </button>
                </form>

                {/* WhatsApp Preview & Copy */}
                <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
                      <div>
                        <h3 className="text-base font-semibold text-slate-900">
                          Pratinjau Format WhatsApp
                        </h3>
                        <p className="text-xs text-slate-500">
                          Ringkasan OPS &amp; Try-on siap kirim ke grup
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyText(liveWaText, 'live')}
                        className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors whitespace-nowrap"
                      >
                        {copiedKey === 'live' ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            Tersalin
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            Copy Format WhatsApp
                          </>
                        )}
                      </button>
                    </div>

                    <pre className="mt-4 p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-slate-800 whitespace-pre-wrap leading-relaxed max-h-[460px] overflow-y-auto">
                      {liveWaText}
                    </pre>
                  </div>
                </div>
              </div>

              {/* Archive Cashier Reports */}
              <section className="bg-white border border-slate-200 rounded-xl p-5">
                <h3 className="text-base font-semibold text-slate-900 mb-3">
                  Arsip Laporan Kasir ({formatWeekLabel(weekKey)})
                </h3>
                {cashierReports.filter((r) => r.weekKey === weekKey).length === 0 ? (
                  <p className="py-8 text-center text-sm text-slate-500">
                    Belum ada arsip laporan kasir pada minggu ini.
                  </p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 text-xs font-medium text-slate-500">
                          <th className="py-2 pr-3">Tanggal</th>
                          <th className="py-2 px-3">Shift / Kasir</th>
                          <th className="py-2 px-3 text-right">OPS (Open Studio)</th>
                          <th className="py-2 px-3 text-right">Total Try-on</th>
                          <th className="py-2 px-3">Rincian Try-on</th>
                          <th className="py-2 pl-3 text-right">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {cashierReports
                          .filter((r) => r.weekKey === weekKey)
                          .map((rep) => (
                            <tr key={rep.id} className="hover:bg-slate-50/70">
                              <td className="py-2.5 pr-3 font-mono text-xs tabular-nums">
                                {rep.date}
                              </td>
                              <td className="py-2.5 px-3">
                                <div className="font-medium text-slate-900">{rep.cashierName}</div>
                                <div className="text-xs text-slate-500">{rep.shift}</div>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                                {rep.openStudioCount} sesi ({rep.openStudioParticipants} org)
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums">
                                {rep.totalTryOnCount} sesi
                              </td>
                              <td className="py-2.5 px-3 text-xs text-slate-600 font-mono tabular-nums">
                                AirPods {rep.tryOnCounts.airpods} · iPad {rep.tryOnCounts.ipad} · Watch {rep.tryOnCounts.watch}
                              </td>
                              <td className="py-2.5 pl-3 text-right whitespace-nowrap space-x-2">
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleCopyText(
                                      formatCashierWhatsAppText(rep, storeSettings.storeName),
                                      rep.id,
                                    )
                                  }
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded border border-emerald-200"
                                >
                                  {copiedKey === rep.id ? 'Tersalin' : 'Copy WA'}
                                </button>
                                {adminUnlocked && (
                                  <button
                                    type="button"
                                    onClick={() => onDeleteCashierReport(rep.id)}
                                    className="inline-flex items-center p-1 text-red-600 hover:text-red-700"
                                    title="Hapus laporan"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>
            </div>
          )}

          {/* SUB-TAB 3: WEEKLY EXCEL SCHEDULE UPLOAD & TARGET CONFIGURATION */}
          {activeSubTab === 'schedule_target' && (
            <div className="space-y-6">
              <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                  <div>
                    <h2 className="text-lg font-semibold text-slate-900">
                      Otomatisasi Jadwal Mingguan (Senin–Minggu) · {formatWeekLabel(weekKey)}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Mendukung file .xlsx atau .csv dengan kolom Senin sampai Minggu (P = Pagi, M = Middle, S = Siang, X = Off).
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => downloadWeeklyTemplateExcel(weekKey)}
                      className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Download Template Mingguan
                    </button>
                    <button
                      type="button"
                      onClick={onLoadSampleSchedule}
                      className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      Muat Jadwal Contoh
                    </button>
                  </div>
                </div>

                <div className="p-6 border-2 border-dashed border-slate-300 rounded-xl bg-slate-50/70 text-center">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleExcelFile}
                    className="hidden"
                  />
                  <UploadCloud className="w-8 h-8 text-slate-500 mx-auto" />
                  <p className="mt-2 text-sm font-medium text-slate-900">
                    Pilih file Excel Jadwal Mingguan (.xlsx / .csv) untuk {formatWeekLabel(weekKey)}
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    Diproses langsung di browser menggunakan SheetJS (xlsx) dan disinkronkan real-time ke Firestore.
                  </p>
                  <button
                    type="button"
                    disabled={uploadingExcel}
                    onClick={() => fileInputRef.current?.click()}
                    className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-60"
                  >
                    {uploadingExcel ? 'Memproses Excel...' : 'Pilih & Proses File Excel'}
                  </button>
                </div>

                {excelStatus && (
                  <div
                    className={`p-3 rounded-lg text-sm border ${
                      excelStatus.type === 'success'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-red-50 text-red-800 border-red-200'
                    }`}
                  >
                    {excelStatus.text}
                  </div>
                )}

                <div>
                  <p className="text-xs font-semibold text-slate-700 mb-2">
                    Contoh Struktur Kolom Excel Mingguan yang Didukung
                  </p>
                  <div className="overflow-x-auto border border-slate-200 rounded-lg">
                    <table className="w-full text-left text-xs font-mono border-collapse">
                      <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                        <tr>
                          <th className="py-2 px-3">Nama Staff</th>
                          <th className="py-2 px-3">Jabatan</th>
                          <th className="py-2 px-2 text-center">Senin</th>
                          <th className="py-2 px-2 text-center">Selasa</th>
                          <th className="py-2 px-2 text-center">Rabu</th>
                          <th className="py-2 px-2 text-center">Kamis</th>
                          <th className="py-2 px-2 text-center">Jumat</th>
                          <th className="py-2 px-2 text-center">Sabtu</th>
                          <th className="py-2 px-2 text-center">Minggu</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        <tr>
                          <td className="py-2 px-3 font-sans">Andi Pratama</td>
                          <td className="py-2 px-3 font-sans">Apple Specialist</td>
                          <td className="py-2 px-2 text-center">P</td>
                          <td className="py-2 px-2 text-center">M</td>
                          <td className="py-2 px-2 text-center">S</td>
                          <td className="py-2 px-2 text-center">X</td>
                          <td className="py-2 px-2 text-center">P</td>
                          <td className="py-2 px-2 text-center">M</td>
                          <td className="py-2 px-2 text-center">S</td>
                        </tr>
                        <tr>
                          <td className="py-2 px-3 font-sans">Nadia Kusuma</td>
                          <td className="py-2 px-3 font-sans">Creative Trainer</td>
                          <td className="py-2 px-2 text-center">M</td>
                          <td className="py-2 px-2 text-center">S</td>
                          <td className="py-2 px-2 text-center">X</td>
                          <td className="py-2 px-2 text-center">P</td>
                          <td className="py-2 px-2 text-center">M</td>
                          <td className="py-2 px-2 text-center">S</td>
                          <td className="py-2 px-2 text-center">P</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </section>

              {/* Target Configurator */}
              <form
                onSubmit={handleSaveTargets}
                className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                  <div>
                    <h3 className="text-base font-semibold text-slate-900">
                      Pengaturan Target Mingguan ({formatWeekLabel(weekKey)})
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Otomatis dari total shift aktif ({computedPreview.totalActiveShifts} shift P/M/S) atau override manual.
                    </p>
                  </div>
                  <div className="inline-flex p-1 bg-slate-100 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setTargetMode('auto')}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                        targetMode === 'auto'
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-600'
                      }`}
                    >
                      Mode Otomatis
                    </button>
                    <button
                      type="button"
                      onClick={() => setTargetMode('manual')}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                        targetMode === 'manual'
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-600'
                      }`}
                    >
                      Mode Manual Override
                    </button>
                  </div>
                </div>

                {targetMode === 'auto' ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      { key: 'openStudio', label: 'Kuota Open Studio / Shift' },
                      { key: 'airpods', label: 'Kuota AirPods / Shift' },
                      { key: 'ipad', label: 'Kuota iPad / Shift' },
                      { key: 'watch', label: 'Kuota Apple Watch / Shift' },
                    ].map((q) => {
                      const k = q.key as keyof TargetQuotas;
                      return (
                        <div key={q.key} className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                          <label className="block text-xs font-medium text-slate-700 mb-1">
                            {q.label}
                          </label>
                          <input
                            type="number"
                            step="0.5"
                            min={0}
                            max={50}
                            value={dailyQuotas[k]}
                            onChange={(e) =>
                              setDailyQuotas((prev) => ({
                                ...prev,
                                [k]: Math.max(0, Number(e.target.value) || 0),
                              }))
                            }
                            className="w-full min-h-[38px] px-2.5 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-md"
                          />
                          <p className="mt-1.5 text-xs font-mono text-slate-500 tabular-nums">
                            Target: {computedPreview.totalActiveShifts} × {dailyQuotas[k]} ={' '}
                            <strong className="text-slate-900">{computedPreview.targets[k]}</strong>
                          </p>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {[
                        { key: 'openStudio', label: 'Target Toko: Open Studio' },
                        { key: 'airpods', label: 'Target Toko: Try-on AirPods' },
                        { key: 'ipad', label: 'Target Toko: Try-on iPad' },
                        { key: 'watch', label: 'Target Toko: Try-on Watch' },
                      ].map((m) => {
                        const k = m.key as keyof TargetQuotas;
                        return (
                          <div key={m.key}>
                            <label className="block text-xs font-medium text-slate-700 mb-1">
                              {m.label}
                            </label>
                            <input
                              type="number"
                              min={0}
                              value={manualTotals[k]}
                              onChange={(e) =>
                                setManualTotals((prev) => ({
                                  ...prev,
                                  [k]: Math.max(0, Number.parseInt(e.target.value, 10) || 0),
                                }))
                              }
                              className="w-full min-h-[40px] px-3 py-2 text-sm font-mono bg-white border border-slate-300 rounded-lg"
                            />
                          </div>
                        );
                      })}
                    </div>

                    {staffRoster.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-slate-800 mb-2">
                          Override Target Per Individu Staff (Opsional)
                        </p>
                        <div className="overflow-x-auto border border-slate-200 rounded-lg">
                          <table className="w-full text-left text-xs border-collapse">
                            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                              <tr>
                                <th className="py-2 px-3">Nama Staff</th>
                                <th className="py-2 px-2">Open Studio</th>
                                <th className="py-2 px-2">AirPods</th>
                                <th className="py-2 px-2">iPad</th>
                                <th className="py-2 px-2">Watch</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                              {staffRoster.map((staff) => {
                                const ov = staffOverrides[staff.staffId];
                                return (
                                  <tr key={staff.staffId}>
                                    <td className="py-2 px-3 font-medium text-slate-900">
                                      {staff.name}{' '}
                                      <span className="text-slate-400 font-mono">
                                        ({staff.totalActiveDays}d)
                                      </span>
                                    </td>
                                    {(['openStudio', 'airpods', 'ipad', 'watch'] as (keyof TargetQuotas)[]).map(
                                      (f) => (
                                        <td key={f} className="py-1.5 px-2">
                                          <input
                                            type="number"
                                            min={0}
                                            placeholder={String(
                                              Math.round(staff.totalActiveDays * dailyQuotas[f]),
                                            )}
                                            value={ov ? ov[f] : ''}
                                            onChange={(e) =>
                                              updateStaffOverrideField(
                                                staff.staffId,
                                                f,
                                                Number.parseInt(e.target.value, 10) || 0,
                                              )
                                            }
                                            className="w-20 px-2 py-1 font-mono bg-white border border-slate-300 rounded"
                                          />
                                        </td>
                                      ),
                                    )}
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {targetMessage && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm">
                    {targetMessage}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={savingTargets}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-60"
                >
                  <Save className="w-4 h-4" />
                  {savingTargets ? 'Menyimpan...' : 'Simpan Pengaturan Target'}
                </button>
              </form>
            </div>
          )}

          {/* SUB-TAB 4: GOOGLE DRIVE 4-FOLDER INTEGRATION & DEPLOY GUIDE */}
          {activeSubTab === 'integration' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <form
                onSubmit={handleSaveSettings}
                className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4"
              >
                <div className="pb-3 border-b border-slate-100">
                  <h2 className="text-lg font-semibold text-slate-900">
                    Konfigurasi 4 Folder Google Drive & Web App GAS
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Keempat folder Google Drive sudah terhubung sesuai kategori aktivitas. Pasang URL
                    Web App Google Apps Script untuk upload otomatis 1-klik dari HP staff.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Nama Toko / Cabang
                  </label>
                  <input
                    type="text"
                    required
                    value={storeNameInput}
                    onChange={(e) => setStoreNameInput(e.target.value)}
                    className="w-full min-h-[42px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                  />
                </div>

                <div className="space-y-3 pt-1">
                  <p className="text-xs font-semibold text-slate-800">
                    Folder Google Drive per Kategori (Sudah Terkonfigurasi)
                  </p>
                  {[
                    { key: 'openStudio', label: 'Folder Open Studio' },
                    { key: 'airpods', label: 'Folder Try-on AirPods' },
                    { key: 'ipad', label: 'Folder Try-on iPad' },
                    { key: 'watch', label: 'Folder Try-on Apple Watch' },
                  ].map((item) => {
                    const k = item.key as keyof DriveFolderMap;
                    return (
                      <div key={item.key}>
                        <label className="block text-[11px] font-medium text-slate-600 mb-1">
                          {item.label}
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="url"
                            required
                            value={driveFoldersInput[k]}
                            onChange={(e) =>
                              setDriveFoldersInput((prev) => ({
                                ...prev,
                                [k]: e.target.value,
                              }))
                            }
                            className="flex-1 min-h-[38px] px-3 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                          />
                          <a
                            href={driveFoldersInput[k]}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg shrink-0"
                          >
                            <FolderOpen className="w-3.5 h-3.5" />
                            Buka
                          </a>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="pt-2 space-y-3">
                  <p className="text-xs font-semibold text-slate-800">
                    Link Submit Report & Survey Try-on (Sidebar)
                  </p>
                  {[
                    { key: 'openStudio', label: 'Submit Link Report: Open Studio', placeholder: 'https://forms.gle/...' },
                    { key: 'airpods', label: 'Survey Try-on: AirPods', placeholder: 'https://docs.google.com/forms/...' },
                    { key: 'ipad', label: 'Survey Try-on: iPad', placeholder: 'https://forms.gle/...' },
                    { key: 'watch', label: 'Survey Try-on: Apple Watch (kosongkan = Segera hadir)', placeholder: 'Segera hadir — isi URL Google Form saat siap' },
                  ].map((item) => {
                    const k = item.key as keyof SurveyLinkMap;
                    return (
                      <div key={item.key}>
                        <label className="block text-[11px] font-medium text-slate-600 mb-1">
                          {item.label}
                        </label>
                        <input
                          type="url"
                          value={surveyLinksInput[k]}
                          onChange={(e) =>
                            setSurveyLinksInput((prev) => ({
                              ...prev,
                              [k]: e.target.value,
                            }))
                          }
                          placeholder={item.placeholder}
                          className="w-full min-h-[38px] px-3 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                        />
                      </div>
                    );
                  })}
                </div>

                <div className="pt-2">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Endpoint URL Google Apps Script Web App (Untuk Upload Otomatis)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={driveScriptUrlInput}
                      onChange={(e) => setDriveScriptUrlInput(e.target.value)}
                      placeholder="https://script.google.com/macros/s/.../exec"
                      className="flex-1 min-h-[42px] px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                    />
                    <button
                      type="button"
                      disabled={testingBridge || !driveScriptUrlInput.trim()}
                      onClick={handleTestBridge}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg shrink-0 disabled:opacity-50"
                    >
                      <Wifi className="w-3.5 h-3.5" />
                      {testingBridge ? 'Tes...' : 'Tes Koneksi'}
                    </button>
                  </div>
                </div>

                {bridgeTestResult && (
                  <div
                    className={`p-3 rounded-lg text-xs border ${
                      bridgeTestResult.ok
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-red-50 text-red-800 border-red-200'
                    }`}
                  >
                    {bridgeTestResult.text}
                  </div>
                )}

                {settingsSavedMsg && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm">
                    {settingsSavedMsg}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={savingSettings}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg disabled:opacity-60"
                >
                  <Save className="w-4 h-4" />
                  {savingSettings ? 'Menyimpan...' : 'Simpan Konfigurasi'}
                </button>
              </form>

              {/* Pre-configured Code.gs + Online Deploy Guide */}
              <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4">
                <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div>
                    <h3 className="text-base font-semibold text-slate-900">
                      Script Google Apps Script Siap Pakai (Code.gs)
                    </h3>
                    <p className="text-xs text-slate-500">
                      Sudah terisi 4 ID Folder Google Drive Anda (Open Studio, AirPods, iPad, Watch)
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopyText(GOOGLE_APPS_SCRIPT_TEMPLATE, 'gas')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                  >
                    {copiedKey === 'gas' ? 'Tersalin!' : 'Salin Code.gs'}
                  </button>
                </div>

                <pre className="p-3.5 bg-slate-900 text-slate-100 rounded-lg text-[11px] font-mono overflow-x-auto leading-relaxed max-h-60">
                  {GOOGLE_APPS_SCRIPT_TEMPLATE}
                </pre>

                <div className="pt-2 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                  <p className="font-semibold text-slate-900">
                    Tutorial Agar Dashboard Bisa Online via GitHub (Vercel / Netlify)
                  </p>
                  <ol className="list-decimal list-inside space-y-1.5 leading-relaxed">
                    <li>
                      <strong>Buat Repository GitHub</strong>: Buka github.com → <strong>New Repository</strong> (misal <code className="font-mono bg-slate-100 px-1 rounded">storeops-dashboard</code>).
                    </li>
                    <li>
                      <strong>Push Project ke GitHub</strong>: Jalankan di terminal folder project:
                      <code className="block mt-1 p-2 font-mono bg-slate-100 rounded text-[11px]">
                        git init &amp;&amp; git add . &amp;&amp; git commit -m &quot;Initial StoreOps&quot; &amp;&amp; git branch -M main &amp;&amp; git remote add origin https://github.com/USERNAME/storeops-dashboard.git &amp;&amp; git push -u origin main
                      </code>
                    </li>
                    <li>
                      <strong>Deploy Online Gratis di Vercel</strong>: Buka <code className="font-mono bg-slate-100 px-1 rounded">vercel.com</code> → Login GitHub → <strong>Add New Project</strong> → Pilih repo Anda → Framework: <strong>Vite</strong>, Build Command: <code className="font-mono bg-slate-100 px-1 rounded">npm run build</code>, Output Directory: <code className="font-mono bg-slate-100 px-1 rounded">dist</code> → Klik <strong>Deploy</strong>.
                    </li>
                    <li>
                      <strong>Pasang Google Apps Script (Opsional Upload Kamera)</strong>: Tempel <code className="font-mono bg-slate-100 px-1 rounded">Code.gs</code> di <code className="font-mono bg-slate-100 px-1 rounded">script.google.com</code> → Deploy Web App (<code className="font-mono bg-slate-100 px-1 rounded">Anyone</code>) → masukkan URL <code className="font-mono bg-slate-100 px-1 rounded">/exec</code> di sebelah kiri.
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
