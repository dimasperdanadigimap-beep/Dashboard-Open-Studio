import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Calendar,
  CheckCircle2,
  ClipboardPlus,
  Clock,
  ExternalLink,
  FileText,
  FolderOpen,
  Receipt,
  Sparkles,
  UploadCloud,
  Users,
} from 'lucide-react';
import {
  computeWeeklyActivitySeries,
  computeWeeklyTargetsAndActuals,
  getActiveStaffForDate,
} from '../lib/analytics';
import {
  formatDateID,
  formatWeekLabel,
  SHIFT_META,
} from '../lib/formatters';
import {
  AppTab,
  CashierReport,
  StaffActivity,
  StoreSettings,
  WeeklySchedule,
  WeeklyStaffShift,
  WeeklyTargetConfig,
} from '../types/operations';

interface DashboardOverviewProps {
  weekKey: string;
  selectedDate: string;
  loadingData: boolean;
  storeSettings: StoreSettings;
  scheduleMeta: WeeklySchedule | null;
  staffRoster: WeeklyStaffShift[];
  targetConfig: WeeklyTargetConfig | null;
  activities: StaffActivity[];
  cashierReports: CashierReport[];
  onNavigateTab: (tab: AppTab, preselectStaffId?: string) => void;
  onLoadSampleSchedule: () => Promise<void>;
  onSelectDate: (dateStr: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  weekKey,
  selectedDate,
  loadingData,
  storeSettings,
  scheduleMeta,
  staffRoster,
  targetConfig,
  activities,
  cashierReports,
  onNavigateTab,
  onLoadSampleSchedule,
  onSelectDate,
}) => {
  const [hoveredDay, setHoveredDay] = useState<string | null>(null);
  const [loadingSample, setLoadingSample] = useState(false);

  const summary = useMemo(
    () => computeWeeklyTargetsAndActuals(staffRoster, activities, targetConfig, weekKey),
    [staffRoster, activities, targetConfig, weekKey],
  );

  const activeStaffToday = useMemo(
    () => getActiveStaffForDate(staffRoster, activities, selectedDate),
    [staffRoster, activities, selectedDate],
  );

  const inactiveStaffToday = useMemo(
    () => activeStaffToday.filter((item) => item.activitiesToday.length === 0),
    [activeStaffToday],
  );

  const offStaffCountToday = useMemo(
    () => Math.max(0, staffRoster.length - activeStaffToday.length),
    [staffRoster.length, activeStaffToday.length],
  );

  const weeklySeries = useMemo(
    () => computeWeeklyActivitySeries(activities, weekKey),
    [activities, weekKey],
  );

  const maxDailyTotal = useMemo(() => {
    const maxVal = Math.max(...weeklySeries.map((p) => p.openStudio + p.tryOn), 4);
    return maxVal;
  }, [weeklySeries]);

  const weekActivities = useMemo(
    () => activities.filter((a) => a.weekKey === weekKey),
    [activities, weekKey],
  );

  const todayActivities = useMemo(
    () => activities.filter((a) => a.date === selectedDate),
    [activities, selectedDate],
  );

  const todayOpenStudioCount = useMemo(
    () => todayActivities.filter((a) => a.activityType === 'open_studio').length,
    [todayActivities],
  );

  const todayOpenStudioParticipants = useMemo(
    () =>
      todayActivities
        .filter((a) => a.activityType === 'open_studio')
        .reduce((sum, a) => sum + (a.participantsCount || 0), 0),
    [todayActivities],
  );

  const todayTryOnBreakdown = useMemo(() => {
    const counts = { airpods: 0, ipad: 0, watch: 0 };
    for (const act of todayActivities) {
      if (act.activityType !== 'try_on') continue;
      if (act.productCategory === 'AirPods') counts.airpods += 1;
      else if (act.productCategory === 'iPad') counts.ipad += 1;
      else if (act.productCategory === 'Apple Watch') counts.watch += 1;
    }
    return {
      ...counts,
      total: counts.airpods + counts.ipad + counts.watch,
    };
  }, [todayActivities]);

  const todayCashierReports = useMemo(
    () => cashierReports.filter((r) => r.date === selectedDate),
    [cashierReports, selectedDate],
  );

  const kpiCards = [
    {
      key: 'openStudio',
      label: 'Open Studio',
      subtitle: 'Sesi Demo & Edukasi',
      actual: summary.actuals.openStudio,
      target: summary.targets.openStudio,
      pct: summary.percentages.openStudio,
      barColor: 'bg-slate-900',
      driveUrl: storeSettings.driveFolders.openStudio,
      surveyUrl: storeSettings.surveyLinks.openStudio,
      surveyLabel: 'Submit Report',
    },
    {
      key: 'airpods',
      label: 'Try-on AirPods',
      subtitle: 'Audio Experience',
      actual: summary.actuals.airpods,
      target: summary.targets.airpods,
      pct: summary.percentages.airpods,
      barColor: 'bg-sky-600',
      driveUrl: storeSettings.driveFolders.airpods,
      surveyUrl: storeSettings.surveyLinks.airpods,
      surveyLabel: 'Survey Try-on',
    },
    {
      key: 'ipad',
      label: 'Try-on iPad',
      subtitle: 'Creative & Productivity',
      actual: summary.actuals.ipad,
      target: summary.targets.ipad,
      pct: summary.percentages.ipad,
      barColor: 'bg-indigo-600',
      driveUrl: storeSettings.driveFolders.ipad,
      surveyUrl: storeSettings.surveyLinks.ipad,
      surveyLabel: 'Survey Try-on',
    },
    {
      key: 'watch',
      label: 'Try-on Apple Watch',
      subtitle: 'Health & Wearable',
      actual: summary.actuals.watch,
      target: summary.targets.watch,
      pct: summary.percentages.watch,
      barColor: 'bg-amber-600',
      driveUrl: storeSettings.driveFolders.watch,
      surveyUrl: storeSettings.surveyLinks.watch,
      surveyLabel: 'Survey Try-on',
    },
  ];

  const handleSampleClick = async () => {
    setLoadingSample(true);
    try {
      await onLoadSampleSchedule();
    } finally {
      setLoadingSample(false);
    }
  };

  if (loadingData) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-20 bg-white border border-slate-200 rounded-xl p-4 animate-pulse"
            />
          ))}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-36 bg-white border border-slate-200 rounded-xl p-5 animate-pulse"
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Daily Snapshot Strip */}
      <section
        aria-label="Ringkasan Operasional Hari Ini"
        className="grid grid-cols-2 lg:grid-cols-4 gap-4"
      >
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Aktivitas Masuk ({formatDateID(selectedDate)})</p>
          <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
            {todayActivities.length} log
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">OPS / Open Studio Hari Ini</p>
          <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
            {todayOpenStudioCount} sesi · {todayOpenStudioParticipants} org
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Try-on Dilakukan Hari Ini</p>
          <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
            {todayTryOnBreakdown.total} sesi
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500">Kepatuhan Shift Aktif Hari Ini</p>
          <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
            {activeStaffToday.length - inactiveStaffToday.length} / {activeStaffToday.length} staff
          </p>
        </div>
      </section>

      {/* Empty Schedule Banner when no Weekly Excel uploaded */}
      {staffRoster.length === 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-amber-700">
              Jadwal mingguan belum tersedia · {formatWeekLabel(weekKey)}
            </p>
            <h2 className="mt-1 text-lg font-semibold text-slate-900">
              Unggah Jadwal Excel Mingguan (Senin–Minggu) untuk Mengaktifkan Tracking
            </h2>
            <p className="mt-1 text-sm text-slate-600 max-w-2xl">
              Sistem membaca kode shift P, M, S, dan X untuk hari Senin hingga Minggu, memfilter
              dropdown input aktivitas staff, serta menghitung target mingguan otomatis.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleSampleClick}
              disabled={loadingSample}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap disabled:opacity-60"
            >
              <Sparkles className="w-4 h-4" />
              {loadingSample ? 'Memuat...' : 'Muat Jadwal Contoh (Admin)'}
            </button>
            <button
              type="button"
              onClick={() => onNavigateTab('admin_cashier')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap"
            >
              <UploadCloud className="w-4 h-4" />
              Upload Jadwal Excel
            </button>
          </div>
        </div>
      )}

      {/* Row 1: 4 Weekly KPI Progress Cards with Drive + Survey Links */}
      <section aria-label="Pencapaian Target Mingguan">
        <div className="flex flex-wrap items-baseline justify-between gap-2 mb-3">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Pencapaian Target Mingguan (Senin–Minggu)
            </h2>
            <p className="text-xs text-slate-500">
              {formatWeekLabel(weekKey)} ·{' '}
              {summary.mode === 'auto'
                ? `Mode Otomatis (${summary.totalActiveShifts} total shift aktif P/M/S)`
                : 'Mode Manual Override'}
              {scheduleMeta ? ` · File: ${scheduleMeta.fileName}` : ''}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigateTab('input')}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-sky-700 hover:text-sky-800 whitespace-nowrap"
          >
            <ClipboardPlus className="w-4 h-4" />
            Input Aktivitas Baru
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpiCards.map((card) => (
            <div
              key={card.key}
              className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-medium text-slate-700">
                    {card.label}
                  </span>
                  <span className="font-mono text-xs font-semibold text-slate-900 tabular-nums">
                    {card.pct}%
                  </span>
                </div>
                <p className="mt-0.5 text-xs text-slate-500">{card.subtitle}</p>
              </div>

              <div className="mt-4">
                <div className="flex items-baseline gap-1.5">
                  <span className="font-mono text-2xl font-semibold text-slate-900 tabular-nums">
                    {card.actual}
                  </span>
                  <span className="font-mono text-sm text-slate-400 tabular-nums">
                    / {card.target}
                  </span>
                </div>

                <div className="mt-3 h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${card.barColor} transition-all duration-300`}
                    style={{ width: `${Math.min(100, card.pct)}%` }}
                  />
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                  <a
                    href={card.driveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-medium text-slate-600 hover:text-slate-900"
                  >
                    <FolderOpen className="w-3.5 h-3.5" />
                    Drive
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  {card.surveyUrl ? (
                    <a
                      href={card.surveyUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs font-medium text-sky-700 hover:text-sky-800"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      {card.surveyLabel}
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] text-slate-400">
                      <Clock className="w-3 h-3" />
                      Segera hadir
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Row 2: Weekly Senin-Minggu Chart + Inactive Staff Tracker */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Aktivitas Mingguan (Senin – Minggu)
              </h3>
              <p className="text-xs text-slate-500">
                Klik hari pada grafik untuk memfilter tanggal aktif
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-600">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-slate-900 inline-block" />
                Open Studio
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-sky-500 inline-block" />
                Try-on Produk
              </span>
            </div>
          </div>

          <div className="relative flex-1 min-h-[220px] flex flex-col justify-end pt-4">
            {hoveredDay && (
              <div className="mb-3 text-xs text-slate-700 font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 inline-flex items-center gap-3 self-start">
                {(() => {
                  const pt = weeklySeries.find((p) => p.dateStr === hoveredDay);
                  return (
                    <>
                      <span className="font-semibold">
                        {pt?.dayLabel} ({pt?.dayMonthLabel})
                      </span>
                      <span>·</span>
                      <span>Open Studio: {pt?.openStudio ?? 0}</span>
                      <span>·</span>
                      <span>Try-on: {pt?.tryOn ?? 0}</span>
                    </>
                  );
                })()}
              </div>
            )}

            <div className="grid grid-cols-7 gap-3 h-44 border-b border-slate-200 pb-2 items-end">
              {weeklySeries.map((pt) => {
                const total = pt.openStudio + pt.tryOn;
                const openH = Math.round((pt.openStudio / maxDailyTotal) * 140);
                const tryH = Math.round((pt.tryOn / maxDailyTotal) * 140);
                const isSelected = pt.dateStr === selectedDate;
                return (
                  <button
                    key={pt.dateStr}
                    type="button"
                    onMouseEnter={() => setHoveredDay(pt.dateStr)}
                    onMouseLeave={() => setHoveredDay(null)}
                    onClick={() => onSelectDate(pt.dateStr)}
                    className={`flex flex-col items-center justify-end h-full rounded-t-lg px-1 pt-2 transition-colors ${
                      isSelected ? 'bg-sky-50 ring-1 ring-sky-200' : 'hover:bg-slate-50'
                    }`}
                  >
                    <span className="font-mono text-[11px] font-medium text-slate-500 mb-1 tabular-nums">
                      {total > 0 ? total : ''}
                    </span>
                    <div className="w-full max-w-[34px] flex flex-col justify-end gap-0.5">
                      {pt.tryOn > 0 && (
                        <div
                          className="w-full bg-sky-500 rounded-t-sm transition-all"
                          style={{ height: `${Math.max(6, tryH)}px` }}
                        />
                      )}
                      {pt.openStudio > 0 && (
                        <div
                          className="w-full bg-slate-900 rounded-t-sm transition-all"
                          style={{ height: `${Math.max(6, openH)}px` }}
                        />
                      )}
                      {total === 0 && (
                        <div className="w-full h-[3px] bg-slate-200 rounded" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-7 gap-3 mt-2 text-center">
              {weeklySeries.map((pt) => {
                const isSelected = pt.dateStr === selectedDate;
                return (
                  <button
                    key={pt.dateStr}
                    type="button"
                    onClick={() => onSelectDate(pt.dateStr)}
                    className={`text-xs transition-colors ${
                      isSelected ? 'font-semibold text-slate-900' : 'text-slate-500'
                    }`}
                  >
                    <div>{pt.shortLabel}</div>
                    <div className="font-mono text-[10px] text-slate-400 tabular-nums">
                      {pt.dayMonthLabel}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 flex flex-col">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Staff Tidak Aktif Hari Ini
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {formatDateID(selectedDate)} · {activeStaffToday.length} shift aktif ·{' '}
                {offStaffCountToday} libur (X) dikecualikan
              </p>
            </div>
            <span
              className={`font-mono text-xs font-semibold px-2 py-1 rounded-md border tabular-nums ${
                inactiveStaffToday.length > 0
                  ? 'bg-red-50 text-red-700 border-red-200'
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              }`}
            >
              {inactiveStaffToday.length} Belum Input
            </span>
          </div>

          <div className="mt-4 flex-1 divide-y divide-slate-100 max-h-64 overflow-y-auto">
            {staffRoster.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">
                Unggah jadwal Excel mingguan untuk melacak keaktifan staff harian.
              </div>
            ) : activeStaffToday.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">
                Tidak ada staff terjadwal P/M/S pada {formatDateID(selectedDate)}.
              </div>
            ) : inactiveStaffToday.length === 0 ? (
              <div className="py-8 text-center">
                <CheckCircle2 className="w-7 h-7 text-emerald-600 mx-auto" />
                <p className="mt-2 text-sm font-medium text-slate-900">
                  Seluruh staff aktif telah mengunggah aktivitas
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {activeStaffToday.length} dari {activeStaffToday.length} staff shift P/M/S patuh hari ini.
                </p>
              </div>
            ) : (
              inactiveStaffToday.map(({ staff, shiftCode }) => {
                const shiftMeta = SHIFT_META[shiftCode];
                return (
                  <div
                    key={staff.staffId}
                    className="py-2.5 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                        <p className="text-sm font-medium text-slate-900 truncate">
                          {staff.name}
                        </p>
                      </div>
                      <p className="text-xs text-slate-500 pl-5.5 truncate">
                        {staff.role} · Shift {shiftCode} ({shiftMeta.label})
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onNavigateTab('input', staff.staffId)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors shrink-0 whitespace-nowrap"
                    >
                      Input
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                );
              })
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="inline-flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              Sudah lapor hari ini:{' '}
              <strong className="font-mono text-slate-800 tabular-nums">
                {activeStaffToday.length - inactiveStaffToday.length}
              </strong>
            </span>
            <button
              type="button"
              onClick={() => onNavigateTab('schedule')}
              className="text-slate-700 hover:text-slate-900 font-medium underline underline-offset-2"
            >
              Lihat Audit Mingguan
            </button>
          </div>
        </section>
      </div>

      {/* Row 3: Recent Activities + Latest Cashier Report */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-5">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Aktivitas Terbaru ({formatWeekLabel(weekKey)})
              </h3>
              <p className="text-xs text-slate-500">
                {weekActivities.length} total log minggu ini · Real-time online
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('input')}
              className="text-xs font-medium text-slate-700 hover:text-slate-900 underline underline-offset-2 whitespace-nowrap"
            >
              + Input Aktivitas
            </button>
          </div>

          {weekActivities.length === 0 ? (
            <div className="py-10 text-center border border-dashed border-slate-200 rounded-lg">
              <Calendar className="w-6 h-6 text-slate-400 mx-auto" />
              <p className="mt-2 text-sm font-medium text-slate-700">
                Belum ada aktivitas tercatat pada minggu ini
              </p>
              <button
                type="button"
                onClick={() => onNavigateTab('input')}
                className="mt-3 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800"
              >
                Catat Aktivitas Pertama
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-medium text-slate-500">
                    <th className="py-2 pr-3">Tanggal</th>
                    <th className="py-2 px-3">Staff</th>
                    <th className="py-2 px-3">Aktivitas</th>
                    <th className="py-2 pl-3 text-right">Bukti</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {weekActivities.slice(0, 6).map((act) => (
                    <tr key={act.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 pr-3 font-mono text-xs text-slate-600 whitespace-nowrap tabular-nums">
                        {act.date}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-medium text-slate-900">{act.staffName}</div>
                        <div className="text-xs text-slate-500">Shift {act.shiftCode}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-medium text-slate-800">
                          {act.activityType === 'open_studio'
                            ? `Open Studio · ${act.topic}`
                            : `Try-on ${act.productCategory}`}
                        </div>
                        <div className="text-xs text-slate-500 truncate max-w-xs">
                          {act.activityType === 'open_studio'
                            ? `${act.participantsCount} peserta`
                            : act.customerNotes || 'Tanpa catatan'}
                        </div>
                      </td>
                      <td className="py-2.5 pl-3 text-right whitespace-nowrap">
                        {act.photoUrl ? (
                          <a
                            href={act.photoUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs font-medium text-sky-700 hover:underline"
                          >
                            Drive
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        ) : (
                          <span className="text-xs text-slate-400">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-base font-semibold text-slate-900">
                  Ringkasan Kasir (OPS &amp; Try-on)
                </h3>
                <Receipt className="w-4 h-4 text-slate-400" />
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {formatDateID(selectedDate)}
              </p>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-600">
                <span>OPS / Open Studio</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {todayOpenStudioCount} sesi ({todayOpenStudioParticipants} org)
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-600">
                <span>Total Try-on Dilakukan</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {todayTryOnBreakdown.total} sesi
                </span>
              </div>
              <div className="pt-2 border-t border-slate-200 grid grid-cols-3 gap-2 text-center text-[11px]">
                <div className="bg-white border border-slate-200 rounded p-1.5">
                  <div className="text-slate-500">AirPods</div>
                  <div className="font-mono font-semibold text-slate-900 tabular-nums">
                    {todayTryOnBreakdown.airpods}
                  </div>
                </div>
                <div className="bg-white border border-slate-200 rounded p-1.5">
                  <div className="text-slate-500">iPad</div>
                  <div className="font-mono font-semibold text-slate-900 tabular-nums">
                    {todayTryOnBreakdown.ipad}
                  </div>
                </div>
                <div className="bg-white border border-slate-200 rounded p-1.5">
                  <div className="text-slate-500">Watch</div>
                  <div className="font-mono font-semibold text-slate-900 tabular-nums">
                    {todayTryOnBreakdown.watch}
                  </div>
                </div>
              </div>
            </div>

            {todayCashierReports.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-2">
                Belum ada rekap closing shift tersimpan pada tanggal ini.
              </p>
            ) : (
              <div className="space-y-2">
                {todayCashierReports.slice(0, 2).map((rep) => (
                  <div
                    key={rep.id}
                    className="p-3 bg-white border border-slate-200 rounded-lg text-xs"
                  >
                    <div className="flex items-center justify-between text-slate-500">
                      <span>Shift {rep.shift}</span>
                      <span>Kasir: {rep.cashierName}</span>
                    </div>
                    <div className="mt-1 font-mono font-semibold text-slate-900 tabular-nums">
                      OPS: {rep.openStudioCount} sesi · Try-on: {rep.totalTryOnCount} sesi
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('admin_cashier')}
            className="mt-4 w-full py-2.5 px-4 text-sm font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Buka Laporan Kasir
          </button>
        </section>
      </div>
    </div>
  );
};
