import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  ExternalLink,
  FolderOpen,
  Image as ImageIcon,
  Link as LinkIcon,
  Loader2,
  Pencil,
  Send,
  Trash2,
  Upload,
} from 'lucide-react';
import { getActiveStaffForDate } from '../lib/analytics';
import {
  compressImageToBase64,
  resolveDriveFolderForActivity,
  uploadPhotoToGoogleDrive,
} from '../lib/driveUploader';
import {
  formatDateID,
  getIsoWeekKeyFromDate,
  SHIFT_META,
} from '../lib/formatters';
import {
  ActivityType,
  PhotoSource,
  StaffActivity,
  StoreSettings,
  TryOnProductCategory,
  WeeklyStaffShift,
} from '../types/operations';

interface StaffActivityFormProps {
  selectedDate: string;
  onChangeDate: (date: string) => void;
  preselectedStaffId?: string;
  staffRoster: WeeklyStaffShift[];
  activities: StaffActivity[];
  storeSettings: StoreSettings;
  onCreateActivity: (
    payload: Omit<
      StaffActivity,
      'id' | 'storeId' | 'verificationStatus' | 'adminNotes' | 'createdAt' | 'updatedAt'
    >,
  ) => Promise<void>;
  onUpdateActivity: (
    activity: StaffActivity,
    patch: Pick<
      StaffActivity,
      'topic' | 'participantsCount' | 'productCategory' | 'customerNotes' | 'photoUrl' | 'photoSource'
    >,
  ) => Promise<void>;
  onDeleteActivity: (id: string) => Promise<void>;
  onGoToDriveConfig: () => void;
}

const OPEN_STUDIO_TOPICS = [
  'iPhone Photography & ProRAW',
  'Mac Productivity Workflow',
  'iPad Notes & Apple Pencil',
  'Apple Watch Health & Fitness',
  'Ekosistem Continuity & AirDrop',
];

export const StaffActivityForm: React.FC<StaffActivityFormProps> = ({
  selectedDate,
  onChangeDate,
  preselectedStaffId,
  staffRoster,
  activities,
  storeSettings,
  onCreateActivity,
  onUpdateActivity,
  onDeleteActivity,
  onGoToDriveConfig,
}) => {
  const activeShiftStaff = useMemo(
    () => getActiveStaffForDate(staffRoster, activities, selectedDate),
    [staffRoster, activities, selectedDate],
  );

  const [staffId, setStaffId] = useState<string>(preselectedStaffId || '');
  const [activityType, setActivityType] = useState<ActivityType>('open_studio');
  const [topic, setTopic] = useState('');
  const [participantsCount, setParticipantsCount] = useState<number>(1);
  const [productCategory, setProductCategory] = useState<TryOnProductCategory>('AirPods');
  const [customerNotes, setCustomerNotes] = useState('');

  const [photoUrl, setPhotoUrl] = useState('');
  const [photoSource, setPhotoSource] = useState<PhotoSource>('none');
  const [localPreview, setLocalPreview] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null,
  );
  const [editingActivity, setEditingActivity] = useState<StaffActivity | null>(null);

  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);

  const targetFolder = useMemo(
    () =>
      resolveDriveFolderForActivity(
        storeSettings.driveFolders,
        activityType,
        activityType === 'try_on' ? productCategory : '',
      ),
    [storeSettings.driveFolders, activityType, productCategory],
  );

  useEffect(() => {
    if (preselectedStaffId) {
      setStaffId(preselectedStaffId);
    }
  }, [preselectedStaffId]);

  useEffect(() => {
    if (activeShiftStaff.length > 0 && !activeShiftStaff.some((s) => s.staff.staffId === staffId)) {
      setStaffId(activeShiftStaff[0].staff.staffId);
    } else if (activeShiftStaff.length === 0) {
      setStaffId('');
    }
  }, [activeShiftStaff, staffId]);

  const selectedStaffItem = useMemo(
    () => activeShiftStaff.find((s) => s.staff.staffId === staffId) || null,
    [activeShiftStaff, staffId],
  );

  const todayHistory = useMemo(
    () => activities.filter((a) => a.date === selectedDate),
    [activities, selectedDate],
  );

  const handleFilePicked = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFeedback(null);
    setUploadingPhoto(true);
    try {
      const compressed = await compressImageToBase64(file);
      setLocalPreview(compressed.previewUrl);

      if (storeSettings.driveScriptUrl.trim().startsWith('https://')) {
        const staffName = selectedStaffItem?.staff.name || 'Staff';
        const safeFilename = `${selectedDate}_${staffName.replace(/\s+/g, '_')}_${
          activityType === 'try_on' ? productCategory : 'OpenStudio'
        }_${Date.now()}.jpg`;
        const uploaded = await uploadPhotoToGoogleDrive(storeSettings.driveScriptUrl, {
          filename: safeFilename,
          mimeType: compressed.mimeType,
          base64Data: compressed.base64,
          staffName,
          activityType,
          productCategory: activityType === 'try_on' ? productCategory : '',
          folderId: targetFolder.folderId,
          date: selectedDate,
        });
        setPhotoUrl(uploaded.url);
        setPhotoSource('gdrive_apps_script');
        setFeedback({
          type: 'success',
          text: `Foto berhasil diunggah otomatis ke folder Google Drive (${targetFolder.label}).`,
        });
      } else {
        setPhotoUrl(targetFolder.url);
        setPhotoSource('drive_folder_fallback');
        setFeedback({
          type: 'error',
          text: `Pratinjau foto siap. Karena Web App GAS belum terpasang, klik "Buka Folder ${targetFolder.label}" untuk upload manual atau aktifkan GAS di menu Admin.`,
        });
      }
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'Gagal memproses atau mengunggah foto.',
      });
    } finally {
      setUploadingPhoto(false);
      e.target.value = '';
    }
  };

  const resetForm = () => {
    setTopic('');
    setParticipantsCount(1);
    setCustomerNotes('');
    setPhotoUrl('');
    setPhotoSource('none');
    setLocalPreview('');
    setEditingActivity(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (editingActivity) {
      if (editingActivity.activityType === 'open_studio' && !topic.trim()) {
        setFeedback({ type: 'error', text: 'Topik Open Studio wajib diisi.' });
        return;
      }
      setSubmitting(true);
      try {
        await onUpdateActivity(editingActivity, {
          topic: editingActivity.activityType === 'open_studio' ? topic.trim() : '',
          participantsCount:
            editingActivity.activityType === 'open_studio' ? Math.max(1, participantsCount) : 1,
          productCategory:
            editingActivity.activityType === 'try_on' ? productCategory : '',
          customerNotes: customerNotes.trim(),
          photoUrl: photoUrl.trim(),
          photoSource: photoUrl.trim() ? photoSource : 'none',
        });
        resetForm();
        setFeedback({
          type: 'success',
          text: 'Perubahan aktivitas berhasil disimpan.',
        });
      } catch (err) {
        setFeedback({
          type: 'error',
          text: err instanceof Error ? err.message : 'Gagal menyimpan pembaruan.',
        });
      } finally {
        setSubmitting(false);
      }
      return;
    }

    if (!selectedStaffItem) {
      setFeedback({
        type: 'error',
        text: 'Pilih staff yang terjadwal shift aktif (P/M/S) pada tanggal ini.',
      });
      return;
    }

    if (activityType === 'open_studio' && !topic.trim()) {
      setFeedback({ type: 'error', text: 'Topik / Materi Open Studio wajib diisi.' });
      return;
    }

    setSubmitting(true);
    try {
      await onCreateActivity({
        date: selectedDate,
        weekKey: getIsoWeekKeyFromDate(selectedDate),
        monthKey: selectedDate.slice(0, 7),
        staffId: selectedStaffItem.staff.staffId,
        staffName: selectedStaffItem.staff.name,
        staffRole: selectedStaffItem.staff.role,
        shiftCode: selectedStaffItem.shiftCode,
        activityType,
        topic: activityType === 'open_studio' ? topic.trim() : '',
        participantsCount: activityType === 'open_studio' ? Math.max(1, participantsCount) : 1,
        productCategory: activityType === 'try_on' ? productCategory : '',
        customerNotes: customerNotes.trim(),
        photoUrl: photoUrl.trim(),
        photoSource: photoUrl.trim() ? (photoSource === 'none' ? 'manual_link' : photoSource) : 'none',
      });
      resetForm();
      setFeedback({
        type: 'success',
        text: `Aktivitas ${activityType === 'open_studio' ? 'Open Studio' : `Try-on ${productCategory}`} untuk ${selectedStaffItem.staff.name} berhasil dicatat.`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'Gagal menyimpan aktivitas.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const startRevisionEdit = (act: StaffActivity) => {
    setEditingActivity(act);
    setActivityType(act.activityType);
    setTopic(act.topic);
    setParticipantsCount(act.participantsCount || 1);
    if (act.productCategory) setProductCategory(act.productCategory);
    setCustomerNotes(act.customerNotes);
    setPhotoUrl(act.photoUrl);
    setPhotoSource(act.photoSource);
    setLocalPreview('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left: Mobile-First Input Form (7 cols) */}
      <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              {editingActivity ? 'Edit Aktivitas Staff' : 'Input Aktivitas Staff'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Otomatis memfilter staff shift aktif (P, M, S) pada jadwal Senin–Minggu.
            </p>
          </div>
          {editingActivity && (
            <button
              type="button"
              onClick={resetForm}
              className="text-xs font-medium text-slate-600 hover:text-slate-900 underline"
            >
              Batal Edit
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Tanggal Aktivitas
              </label>
              <input
                type="date"
                value={selectedDate}
                disabled={Boolean(editingActivity)}
                onChange={(e) => onChangeDate(e.target.value)}
                className="w-full min-h-[44px] px-3 py-2 text-sm font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 disabled:bg-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Nama Staff (Shift Aktif {formatDateID(selectedDate)})
              </label>
              {editingActivity ? (
                <div className="min-h-[44px] px-3 py-2.5 text-sm bg-slate-100 border border-slate-200 rounded-lg text-slate-700">
                  {editingActivity.staffName} · Shift {editingActivity.shiftCode}
                </div>
              ) : (
                <select
                  value={staffId}
                  onChange={(e) => setStaffId(e.target.value)}
                  className="w-full min-h-[44px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                >
                  {activeShiftStaff.length === 0 ? (
                    <option value="">Tidak ada staff shift P/M/S pada tanggal ini</option>
                  ) : (
                    activeShiftStaff.map(({ staff, shiftCode }) => (
                      <option key={staff.staffId} value={staff.staffId}>
                        {staff.name} — Shift {shiftCode} ({SHIFT_META[shiftCode].label})
                      </option>
                    ))
                  )}
                </select>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Jenis Aktivitas
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                disabled={Boolean(editingActivity)}
                onClick={() => setActivityType('open_studio')}
                className={`min-h-[44px] px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  activityType === 'open_studio'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Open Studio
              </button>
              <button
                type="button"
                disabled={Boolean(editingActivity)}
                onClick={() => setActivityType('try_on')}
                className={`min-h-[44px] px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  activityType === 'try_on'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Try-on Produk
              </button>
            </div>
          </div>

          {activityType === 'open_studio' ? (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Topik / Materi Open Studio
                </label>
                <input
                  type="text"
                  required
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Contoh: iPhone Photography & ProRAW"
                  className="w-full min-h-[44px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {OPEN_STUDIO_TOPICS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setTopic(preset)}
                      className="px-2.5 py-1 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Jumlah Peserta
                </label>
                <input
                  type="number"
                  min={1}
                  max={500}
                  required
                  value={participantsCount}
                  onChange={(e) =>
                    setParticipantsCount(Math.max(1, Number.parseInt(e.target.value, 10) || 1))
                  }
                  className="w-36 min-h-[44px] px-3 py-2 text-sm font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Kategori Produk Try-on (Wajib)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['AirPods', 'iPad', 'Apple Watch'] as TryOnProductCategory[]).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setProductCategory(cat)}
                      className={`min-h-[44px] px-3 py-2 text-sm font-medium rounded-lg border transition-colors ${
                        productCategory === cat
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Catatan Singkat Respons Customer
                </label>
                <textarea
                  rows={3}
                  maxLength={500}
                  value={customerNotes}
                  onChange={(e) => setCustomerNotes(e.target.value)}
                  placeholder="Contoh: Customer tertarik ANC AirPods Pro, membandingkan ukuran Apple Watch 42mm vs 46mm..."
                  className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>
            </div>
          )}

          {/* Google Drive Category-Routed Photo Upload */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-sm font-medium text-slate-900">
                  Foto Bukti Google Drive · Folder {targetFolder.label}
                </p>
                <p className="text-xs text-slate-500">
                  {storeSettings.driveScriptUrl
                    ? `Upload otomatis diarahkan ke folder Drive ${targetFolder.label}.`
                    : 'Mode Folder Langsung: pasang Web App GAS di Admin untuk upload otomatis 1-klik.'}
                </p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <a
                  href={targetFolder.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-medium text-sky-700 hover:underline"
                >
                  <FolderOpen className="w-3.5 h-3.5" />
                  Buka Folder
                  <ExternalLink className="w-3 h-3" />
                </a>
                {!storeSettings.driveScriptUrl && (
                  <button
                    type="button"
                    onClick={onGoToDriveConfig}
                    className="text-xs font-medium text-slate-700 hover:text-slate-900 underline"
                  >
                    Setup GAS
                  </button>
                )}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFilePicked}
                className="hidden"
              />
              <input
                ref={galleryInputRef}
                type="file"
                accept="image/*"
                onChange={handleFilePicked}
                className="hidden"
              />
              <button
                type="button"
                disabled={uploadingPhoto}
                onClick={() => cameraInputRef.current?.click()}
                className="flex-1 min-w-[140px] min-h-[44px] inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-60"
              >
                {uploadingPhoto ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Camera className="w-4 h-4" />
                )}
                Kamera HP
              </button>
              <button
                type="button"
                disabled={uploadingPhoto}
                onClick={() => galleryInputRef.current?.click()}
                className="flex-1 min-w-[140px] min-h-[44px] inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-60"
              >
                <Upload className="w-4 h-4" />
                Pilih Galeri
              </button>
            </div>

            {localPreview && (
              <div className="flex items-center gap-3 pt-1">
                <img
                  src={localPreview}
                  alt="Pratinjau foto bukti"
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 object-cover rounded-lg border border-slate-200"
                />
                <div className="text-xs text-slate-600 min-w-0">
                  <p className="font-medium text-slate-800">Foto siap dilampirkan</p>
                  <p className="truncate font-mono">{photoUrl || targetFolder.url}</p>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                Link Foto / Folder Google Drive ({targetFolder.label})
              </label>
              <div className="relative">
                <LinkIcon className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="url"
                  value={photoUrl}
                  onChange={(e) => {
                    setPhotoUrl(e.target.value);
                    setPhotoSource(e.target.value.trim() ? 'manual_link' : 'none');
                  }}
                  placeholder={targetFolder.url}
                  className="w-full min-h-[42px] pl-9 pr-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>
            </div>
          </div>

          {feedback && (
            <div
              className={`p-3 rounded-lg text-sm border ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-red-50 text-red-800 border-red-200'
              }`}
            >
              {feedback.text}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting || uploadingPhoto}
            className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors disabled:opacity-60"
          >
            {submitting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
            {editingActivity ? 'Simpan & Kirim Ulang' : 'Kirim Aktivitas Staff'}
          </button>
        </form>
      </section>

      {/* Right: Today's & Revision History (5 cols) */}
      <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 flex flex-col">
        <div className="pb-4 border-b border-slate-100">
          <h3 className="text-base font-semibold text-slate-900">
            Riwayat Aktivitas Hari Ini
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {formatDateID(selectedDate)} · Log tersinkron real-time
          </p>
        </div>

        <div className="mt-4 space-y-3 flex-1 max-h-[640px] overflow-y-auto">
          {todayHistory.length === 0 ? (
            <div className="py-12 text-center">
              <ImageIcon className="w-7 h-7 text-slate-300 mx-auto" />
              <p className="mt-2 text-sm text-slate-500">
                Belum ada log aktivitas pada tanggal ini.
              </p>
            </div>
          ) : (
            todayHistory.map((act) => (
              <div
                key={act.id}
                className="p-4 border border-slate-200 rounded-xl space-y-2 bg-white"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs font-mono text-slate-500 tabular-nums">
                      {act.date} · Shift {act.shiftCode} · {act.staffName}
                    </p>
                    <h4 className="text-sm font-semibold text-slate-900 mt-0.5">
                      {act.activityType === 'open_studio'
                        ? `Open Studio: ${act.topic}`
                        : `Try-on: ${act.productCategory}`}
                    </h4>
                  </div>
                </div>

                <p className="text-xs text-slate-600">
                  {act.activityType === 'open_studio'
                    ? `${act.participantsCount} peserta`
                    : act.customerNotes || 'Tidak ada catatan customer'}
                </p>

                <div className="pt-1 flex items-center justify-between gap-2 text-xs">
                  {act.photoUrl ? (
                    <a
                      href={act.photoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 font-medium text-sky-700 hover:underline"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Lihat Foto (Drive)
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  ) : (
                    <span className="text-slate-400">Tanpa foto bukti</span>
                  )}

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => startRevisionEdit(act)}
                      className="inline-flex items-center gap-1 text-slate-700 hover:text-slate-900 font-medium"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteActivity(act.id)}
                      className="inline-flex items-center gap-1 text-red-600 hover:text-red-700 font-medium"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Hapus
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
};
