import React, { useMemo, useState } from 'react';
import { Download, Search } from 'lucide-react';
import { computeWeeklyStaffCompliance } from '../lib/analytics';
import {
  formatWeekLabel,
  getWeekDates,
  SHIFT_META,
} from '../lib/formatters';
import {
  ShiftCode,
  StaffActivity,
  WeeklyStaffShift,
  WeeklyTargetConfig,
} from '../types/operations';

interface ScheduleAndAuditViewProps {
  weekKey: string;
  selectedDate: string;
  staffRoster: WeeklyStaffShift[];
  activities: StaffActivity[];
  targetConfig: WeeklyTargetConfig | null;
  onDownloadTemplate: () => void;
}

export const ScheduleAndAuditView: React.FC<ScheduleAndAuditViewProps> = ({
  weekKey,
  selectedDate,
  staffRoster,
  activities,
  targetConfig,
  onDownloadTemplate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const weekDates = useMemo(() => getWeekDates(weekKey), [weekKey]);

  const filteredRoster = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return staffRoster;
    return staffRoster.filter(
      (s) => s.name.toLowerCase().includes(q) || s.role.toLowerCase().includes(q),
    );
  }, [staffRoster, searchQuery]);

  const complianceRows = useMemo(
    () => computeWeeklyStaffCompliance(staffRoster, activities, targetConfig, weekKey),
    [staffRoster, activities, targetConfig, weekKey],
  );

  return (
    <div className="space-y-6">
      {/* Section 1: Weekly Senin-Minggu Shift Matrix */}
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Jadwal Shift Mingguan (Senin – Minggu) · {formatWeekLabel(weekKey)}
            </h2>
            <div className="mt-1.5 flex flex-wrap items-center gap-3 text-xs text-slate-600">
              {(['P', 'M', 'S', 'X'] as ShiftCode[]).map((code) => (
                <span key={code} className="inline-flex items-center gap-1.5">
                  <span
                    className={`inline-flex items-center justify-center w-5 h-5 font-mono text-[11px] font-semibold rounded border ${SHIFT_META[code].className}`}
                  >
                    {code}
                  </span>
                  {SHIFT_META[code].label}
                </span>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari staff / jabatan..."
                className="min-h-[40px] pl-9 pr-3 py-1.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
            <button
              type="button"
              onClick={onDownloadTemplate}
              className="min-h-[40px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Template Excel Mingguan
            </button>
          </div>
        </div>

        {filteredRoster.length === 0 ? (
          <div className="py-12 text-center text-sm text-slate-500">
            Belum ada data jadwal mingguan untuk {formatWeekLabel(weekKey)}. Unggah file Excel di menu Admin & Kasir.
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-medium text-slate-500">
                  <th className="py-2.5 pr-4 min-w-[180px]">Nama Staff</th>
                  {weekDates.map((d) => {
                    const isTodaySelected = d.dateStr === selectedDate;
                    return (
                      <th
                        key={d.key}
                        className={`py-2.5 px-2 text-center min-w-[76px] ${
                          isTodaySelected ? 'bg-sky-50 text-sky-900 rounded-t-lg' : ''
                        }`}
                      >
                        <div className="font-semibold">{d.label}</div>
                        <div className="font-mono text-[11px] font-normal text-slate-400 tabular-nums">
                          {d.dayMonthLabel}
                        </div>
                      </th>
                    );
                  })}
                  <th className="py-2.5 pl-4 text-right whitespace-nowrap">
                    Aktif (P+M+S)
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredRoster.map((staff) => (
                  <tr key={staff.staffId} className="hover:bg-slate-50/60">
                    <td className="py-2.5 pr-4">
                      <div className="font-medium text-slate-900 text-sm">{staff.name}</div>
                      <div className="text-[11px] text-slate-500">{staff.role}</div>
                    </td>
                    {weekDates.map((d) => {
                      const code: ShiftCode = staff.shifts[d.key] || 'X';
                      const isTodaySelected = d.dateStr === selectedDate;
                      return (
                        <td
                          key={d.key}
                          className={`py-2.5 px-2 text-center ${
                            isTodaySelected ? 'bg-sky-50/60' : ''
                          }`}
                        >
                          <span
                            title={`${d.label} (${d.dayMonthLabel}): ${SHIFT_META[code].label}`}
                            className={`inline-flex items-center justify-center w-8 h-7 font-mono text-xs font-semibold rounded-md border ${SHIFT_META[code].className}`}
                          >
                            {code}
                          </span>
                        </td>
                      );
                    })}
                    <td className="py-2.5 pl-4 text-right font-mono font-semibold text-slate-900 tabular-nums whitespace-nowrap">
                      {staff.totalActiveDays} hari
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Section 2: Weekly Compliance Rate Audit */}
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="pb-4 border-b border-slate-100">
          <h3 className="text-base font-semibold text-slate-900">
            Audit Kepatuhan & Produktivitas Mingguan ({formatWeekLabel(weekKey)})
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Compliance Rate dihitung dari rasio hari kerja aktif (P/M/S) Senin–Minggu yang memiliki minimal 1 log aktivitas.
          </p>
        </div>

        {complianceRows.length === 0 ? (
          <div className="py-10 text-center text-sm text-slate-500">
            Data audit kepatuhan akan tampil setelah jadwal mingguan tersedia.
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-medium text-slate-500">
                  <th className="py-2.5 pr-3">Nama Staff</th>
                  <th className="py-2.5 px-3 text-right">Shift Aktif</th>
                  <th className="py-2.5 px-3 text-right">Hari Lapor</th>
                  <th className="py-2.5 px-3 min-w-[140px]">Compliance Rate</th>
                  <th className="py-2.5 px-3 text-right">Open Studio</th>
                  <th className="py-2.5 px-3 text-right">AirPods</th>
                  <th className="py-2.5 px-3 text-right">iPad</th>
                  <th className="py-2.5 px-3 text-right">Watch</th>
                  <th className="py-2.5 pl-3 text-right">Total / Target</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {complianceRows.map((row) => (
                  <tr key={row.staffId} className="hover:bg-slate-50/70">
                    <td className="py-2.5 pr-3">
                      <div className="font-medium text-slate-900">{row.name}</div>
                      <div className="text-xs text-slate-500">{row.role}</div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {row.totalActiveDays}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {row.activeLoggedDays}
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${
                              row.complianceRate >= 80
                                ? 'bg-emerald-600'
                                : row.complianceRate >= 50
                                ? 'bg-amber-500'
                                : 'bg-red-600'
                            }`}
                            style={{ width: `${Math.min(100, row.complianceRate)}%` }}
                          />
                        </div>
                        <span className="font-mono text-xs font-semibold text-slate-800 w-10 text-right tabular-nums">
                          {row.complianceRate}%
                        </span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {row.openStudioCount}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {row.airpodsCount}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {row.ipadCount}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                      {row.watchCount}
                    </td>
                    <td className="py-2.5 pl-3 text-right font-mono tabular-nums whitespace-nowrap">
                      <span className="font-semibold text-slate-900">{row.totalActivities}</span>
                      <span className="text-slate-400"> / {row.targetTotal}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
